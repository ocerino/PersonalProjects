
public interface Position<T> {

	public T getValue();
}
