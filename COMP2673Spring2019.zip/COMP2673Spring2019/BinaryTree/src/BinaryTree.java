import java.util.*;
public class BinaryTree<T> implements Iterable<T> {
	
	private Node root;
	private int size;
	
	public BinaryTree()
	{
		root = null;
		size = 0;
	}
	
	public Position<T> addRoot(T v)
	{
		if(root !=null)
		{
			throw new IllegalStateException("Tree has a root already");
		}
		root = new Node(v,null);
		size++;
		return root;
	}
	
	public Position<T> root()
	{
		return root;
	}
	
	private Node validatePosition(Position<T> p)
	{
		if(p!=null && p instanceof BinaryTree.Node)
		{
			return (Node) p;
		}
		throw new IllegalArgumentException("You must pass a tree position");
	}
	
	public Position<T> addLeft(T v, Position<T> p)
	{
		Node n = validatePosition(p);
		if(n.left ==null)
		{
			n.left = new Node(v,n);
			size++;
			return n.left;
		}
		else
		{
			throw new IllegalStateException("Position already has a left child");
		}
	}
	
	public Position<T> addRight(T v, Position<T> p)
	{
		Node n = validatePosition(p);
		if(n.right ==null)
		{
			n.right = new Node(v,n);
			size++;
			return n.right;
		}
		else
		{
			throw new IllegalStateException("Position already has a right child");
		}
	}
	
	public Position<T> getParent(Position<T> p)
	{
		Node n = validatePosition(p);
		return n.parent;
	}
	
	public boolean hasLeft(Position<T> p)
	{
		Node n = validatePosition(p);
		return n.left != null;
	}
	
	public boolean hasRight(Position<T> p)
	{
		Node n = validatePosition(p);
		return n.right != null;
	}
	
	public Position<T> getLeft(Position<T> p)
	{
		Node n = validatePosition(p);
		return n.left;
	}
	
	public Position<T> getRight(Position<T> p)
	{
		Node n = validatePosition(p);
		return n.right;
	}
	
	public int depth(Position<T> p)
	{
		Node n = validatePosition(p);
		int depth = 0;
		while(n.parent != null)
		{
			depth++;
			n = n.parent;
		}
		return depth;
	}
	
	public int height()
	{
		return height(root);
	}
	
	public int height(Position<T> p)
	{
		Node n = validatePosition(p);
	
		int leftHeight =-1;
		int rightHeight =-1;
		if(n.left!=null)
		{
			leftHeight = height(getLeft(p));
		}
		if(n.right!=null)
		{
			rightHeight = height(getRight(p));
		}
		
		return 1+Math.max(leftHeight, rightHeight);
	}
	
	private String toStringRecursive(StringBuilder sb, Node root, int level)
	{
		//Print the root
		for(int i=0; i < level; i++)
		{
			sb.append("\t");
		}
		sb.append(root + "\n");
		
		if(root.left != null)
		{
			toStringRecursive(sb, root.left,level+1);
		}
		if(root.right != null)
		{
			toStringRecursive(sb, root.right, level+1);
		}
		
		return sb.toString();
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		return toStringRecursive(sb,root,0);
	}
	
	public boolean isExternal(Position<T> p)
	{
		Node n = validatePosition(p);
		return n.left==null && n.right==null;
	}
	
	private void populateSnapshotPreOrder(ArrayList<T> snapshot, Node r)
	{
		if(r!= null)
		{
		snapshot.add(r.value);
		populateSnapshotPreOrder(snapshot,r.left);
		populateSnapshotPreOrder(snapshot,r.right);
		}
	}
	
	public Iterator<T> iterator() 
	{
		ArrayList<T> snapshot = new ArrayList<>();
		populateSnapshotPreOrder(snapshot, root);
		return snapshot.iterator();
	}
	
	private class Node implements Position<T>
	{
		private T value;
		private Node parent;
		private Node left;
		private Node right;
		
		public Node(T v, Node p)
		{
			value = v;
			parent = p;
			left = null;
			right = null;
		}
		
		public T getValue()
		{
			return value;
		}
		
		public String toString()
		{
			return value.toString();
		}
	}

	

}
