
public class Driver {

	public static void main(String[] args) {
		BinaryTree<String> book = new BinaryTree<>();
		
		Position<String> title = book.addRoot("The Giving Tree");
		Position<String> firstChapter =book.addLeft("Introduction", title);
		Position<String> secondChapter =book.addRight("Conclusion", title);
		
		book.addLeft("Give", firstChapter);
		book.addRight("Take", firstChapter);
		
		book.addLeft("Dead", secondChapter);
		Position<String> section = book.addRight("Alive", secondChapter);
		book.addLeft("Zombie", section);
		book.addRight("Vampire", section);
		
		System.out.println(book);
		
		for(String s: book)
		{
			System.out.println(s);
		}

	}

}
