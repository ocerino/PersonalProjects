package edu.du.pearson;

import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.ArrayList;

import edu.princeton.cs.introcs.Draw;
import edu.princeton.cs.introcs.DrawListener;


public class SpatialTree implements DrawListener {

	private SpatialTreeNode root;
	private int size;
	Draw draw = new Draw();
	private boolean isPressed = false;
	Point2D center = null;
	double radius = 0;
	
	public SpatialTree() {
		//create empty tree
		root = null;
		size = 0;
		
		draw.setCanvasSize(500, 500);
		draw.setXscale(0, 500);
		draw.setYscale(0, 500);
		draw.addListener(this);
	}
	
	/**
	 * For every x-node: All descendants in the left subtree have a smaller x-coordinate than the point stored at the node.  
	 * Visually, all descendant points are left of this point. 
	 * All descendants in the right subtree have a larger x-coordinate than the points stored at the node.  
	 * Visually, all descendant points are right of this point. 
	 * For every y-node: All descendants in the left subtree have a smaller y-coordinate than the point stored at the node.  
	 * Visually, all descendant points are below this point. 
	 * All descendants in the right subtree have a larger y-coordinate than the point stored at the node.  
	 * Visually, all descendant points are above this point.
	 */
	
	public void add(Point2D point) {
		SpatialTreeNode n = find(root, point);
		
		if(n == null) {
			root = new SpatialTreeNode(null, true, point);
			size++;
			return;
		} else if(n.point.equals(point)) {
			System.out.println("There is already a point here");
			return;
		}
		 
		if(n.isX) {			//if root/parent is X node, then children will be Y nodes
			if(n.point.getX() < point.getX()) {			//if xCoordinate of new point is larger than xCoordinate of root/parent
				n.right = new SpatialTreeNode(n, !(n.isX()), point);	//new node will become right child
			} else {
				n.left = new SpatialTreeNode(n, !(n.isX()), point);		//new node will become left child
			}
		}
		else			//else root/parent is Y node, children will be X nodes
		{
			if(n.point.getY() < point.getY()) {		//if yCoordinate of new point is larger than yCoordinate of root/parent
				n.right = new SpatialTreeNode(n, !(n.isX()), point );		//new node will become right child
			} else {
				n.left = new SpatialTreeNode(n, !(n.isX), point);			//new node will become left child 
			}	
		}
		++size;
	}
	
	private SpatialTreeNode find(SpatialTreeNode r, Point2D point) {	//finds if point already exists or where point should be
		if(r == null) {
			return null;
		}
		if(r.point.equals(point)) {
			return r;
		}
		//is it x node & left child
		if(r.isX() && point.getX() < r.point.getX() && r.left != null) {
			return find(r.left, point);
		}
		//is it x node & right child 
		if(r.isX() && point.getX() > r.point.getX() && r.right != null) {
			return find(r.right, point);
		}
		//is it y node & below
		if(!r.isX() && point.getY() < r.point.getY() && r.left != null) {
			return find(r.left, point);
		}
		//is it y node & above 
		if(!r.isX() && point.getY() > r.point.getY() && r.right != null) {
			return find(r.right, point);
		}
		return r;	//didn't find value 		
	}
	
	private void draw(SpatialTreeNode r, Point2D L, Point2D R) {			//draw the tree recursively 
		
		//if node is a Xnode 
		if(r != null && r.isX()) {
			draw.setPenColor(draw.BLACK);
			draw.setPenRadius(0.008);		
			draw.point(r.point.getX(), r.point.getY());		//draw the point corresponding to the root 
			
			draw.setPenRadius();
			draw.setPenColor(draw.RED);
			draw.line(r.point.getX(), L.getY(), r.point.getX(), R.getY());	//draw vertical line corresponding to the root
					
			if(r.left != null) {		//recursively draw left subtree of root
				draw(r.left, new Point2D.Double(L.getX(), L.getY()), new Point2D.Double(r.point.getX(), R.getY()));
			}
			if(r.right != null) {		//recursively draw right subtree of root
				draw(r.right, new Point2D.Double(r.point.getX(), L.getY()), new Point2D.Double(R.getX(), R.getY()));
			}		
		}
		//if node is a Ynode
		if(r != null && !r.isX()) {
			draw.setPenColor(draw.BLACK);
			draw.setPenRadius(0.008);		
			draw.point(r.point.getX(), r.point.getY());		//draw the point corresponding to the root
			
			draw.setPenRadius();
			draw.setPenColor(draw.BLUE);
			draw.line(L.getX(), r.point.getY(), R.getX(), r.point.getY());		//draw horizontal line corresponding to the root
			
			if(r.left != null) {		//recursively draw left subtree of root
				draw(r.left, new Point2D.Double(L.getX(), r.point.getY()), new Point2D.Double(R.getX(), R.getY()));
			}
			if(r.right != null) {		//recursively draw right subtree of root
				draw(r.right, new Point2D.Double(L.getX(), L.getY()), new Point2D.Double(R.getX(), r.point.getY()));
			}
		}
	}
	
	public void draw() {		//public draw method 
		draw.clear();
		if(center != null) {										//draw query circle
			draw.circle(center.getX(), center.getY(), radius);
		}
		if(radius > 0) {											//draw center point 
			draw.point(center.getX(), center.getY());
		}
		
		draw(root, new Point2D.Double(0.0, 500.0), new Point2D.Double(500.0, 0.0));
	}
	
	/**
	 * Returns a list of all points contained inside the query circle (the distance to center is less than or equal to radius)
	 * @param center
	 * @param radius
	 * @return result  
	 */
	
	private void query(Point2D center, double radius, SpatialTreeNode r, ArrayList<Point2D> result) {
		
		if(r == null) {
			return;
		}
		
		if(r.point.distance(center) <= radius) {		//if node is within query circle add it to the list
			result.add(r.point);
		}
		
		//if node is a Xnode 
		if(r.isX()) {
			if(Math.abs(r.point.getX()-center.getX()) < radius) {		//if the line of the node intersects with the query circle
				query(center, radius, r.left, result);			//search left subtree
				query(center, radius, r.right, result);			//search right subtree					
			} 
			else if(center.getX() < r.point.getX()) {			//if the query circle is to the left of the node
				query(center, radius, r.left, result);			//search the left subtree
			}
			else {
				query(center, radius, r.right, result);			//the query circle is to the right of the node, search the right subtree
			}
		}
		//if node is a Ynode
		if(!r.isX()) {
			if(Math.abs(r.point.getY()-center.getY()) < radius) {	//if the line of the node intersects with the query circle
				query(center, radius, r.left, result);			//search left subtree
				query(center, radius, r.right, result);			//search right subtree
			}
			else if(center.getY() < r.point.getY()) {		//if the query circle is below the node
				query(center, radius, r.left, result);		//search the left subtree
			} 
			else {
				query(center, radius, r.right, result);		//the query circle is above the node, search the right subtree
			}
		}
	}
	
	public ArrayList<Point2D> query(Point2D center, double radius) {
		ArrayList<Point2D> result = new ArrayList<>();
		query(center, radius, root, result);
		return result;
	}
	

	public void mousePressed(double x, double y) {
		ArrayList<Point2D> result = new ArrayList<>();
		if(center == null) {
			center = new Point2D.Double(x, y);
			draw();

		} else if(radius == 0) {
			radius = center.distance(x, y);
			result = query(center, radius);
			draw();
			
			for(Point2D r : result) {
				draw.setPenRadius(0.005);
				draw.setPenColor(draw.GREEN);
				draw.point(r.getX(), r.getY());
			}
			center = null;
			radius = 0;
		} 
	}
	
	private void toString(SpatialTreeNode r, StringBuilder sb, int level) {
		if(r != null)
		{
			for(int i = 0; i < 2 * level; i++)
			{
				sb.append(" ");
			}
			
			//Recursively print the left and right children
			sb.append(r.toString() + "\n");
			toString(r.left, sb, level + 1);
			toString(r.right, sb, level + 1);
		}
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		toString(root, sb, 0);
		return sb.toString();
	}
	
	private class SpatialTreeNode {

		private SpatialTreeNode left;
		private SpatialTreeNode right;
		private SpatialTreeNode parent;
		private Point2D point;
		private boolean isX;
		
		public SpatialTreeNode(SpatialTreeNode parent, boolean coordinate, Point2D point) {
			this.parent = parent;
			this.isX = coordinate;
			this.point = point;
			left = null;
			right = null;
		}
		public String toString() {
			return (isX ? "x: " : "y: ") + "(" + point.getX() + ", " + point.getY() + ")";
		}
		public boolean isX() {
			return isX;
		}
	}

	public void mouseDragged(double x, double y) {
	}
	public void mouseReleased(double x, double y) {
	}
	public void keyTyped(char c) {
	}
	public void keyPressed(int keycode) {
	}
	public void keyReleased(int keycode) {
	}

}
