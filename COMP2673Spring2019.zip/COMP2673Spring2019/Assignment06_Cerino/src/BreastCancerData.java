
public class BreastCancerData 
{
	private String id, diagnosis;
	private double radius, texture, perimeter, area;
	public BreastCancerData(String id, String diagnosis, double radius, double texture, double perimeter, double area) 
	{
		this.id = id;
		this.diagnosis = diagnosis;
		this.radius = radius;
		this.texture = texture;
		this.perimeter = perimeter;
		this.area = area;
	}
	
	public String toString() {
		return id + ","+ diagnosis + "," + radius + "," + texture+ "," + perimeter + "," + area;
	}
	
	
}
