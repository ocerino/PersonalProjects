import java.io.*;
import java.util.*;

public class Driver2 {

	public static void main(String[] args) 
	{
		String label="";
		Scanner inputStream = null;
		PrintWriter outputStream=null;
		//sets for 3rd attribute or radius
		Set<String> q3_gte_13 = new HashSet<>();
		Set<String> q3_gtb_13 = new HashSet<>();
		Set<String> q3_gtm_13 = new HashSet<>();
		//sets for 4th attribute or texture
		Set<String> q4_gte_18 = new HashSet<>();
		Set<String> q4_gtb_18 = new HashSet<>();
		Set<String> q4_gtm_18 = new HashSet<>();
		//sets for 5th attribute or perimeter
		Set<String> q5_gte_85 = new HashSet<>();
		Set<String> q5_gtb_85 = new HashSet<>();
		Set<String> q5_gtm_85 = new HashSet<>();
		//sets for 6th attribute or area
		Set<String> q6_gte_500 = new HashSet<>();
		Set<String> q6_gtb_500 = new HashSet<>();
		Set<String> q6_gtm_500 = new HashSet<>();
		//map of entire data set
		Map<String, BreastCancerData> completeDataSet= new HashMap<>();  
		//sets for intersection of the 4 files and the 2 different methods
		Set<String> newResult = new HashSet<>();
		Set<String> subsetMResult = new HashSet<>();
		Set<String> originalResult = new HashSet<>();
		Set<String> difference_1 = new HashSet<>();
		Set<String> difference_2 = new HashSet<>();
		
		//read in the data from the files and add them to the appropriate sets
		try {
			inputStream = new Scanner(new FileInputStream("breastCancerDataReducedDimensions.csv"));
			label=inputStream.nextLine();
			
			while(inputStream.hasNextLine())
			{
				String newLine = inputStream.nextLine();
				String[] data = newLine.split(",");
				String id = data[0];
				String diagnosis = data[1];
				double radius = Double.parseDouble(data[2]), texture= Double.parseDouble(data[3]), perimeter= Double.parseDouble(data[4]), area= Double.parseDouble(data[5]);
				BreastCancerData breastCancerData = new BreastCancerData(id, diagnosis, radius, texture, perimeter, area);
				completeDataSet.put(id, breastCancerData);
				if(diagnosis.equalsIgnoreCase("m"))
				{
					originalResult.add(id);
				}
				if(radius>=13)
				{
					q3_gte_13.add(id);
					if(diagnosis.equalsIgnoreCase("m"))
					{
						q3_gtm_13.add(id);
					}
					if(diagnosis.equalsIgnoreCase("b"))
					{
						q3_gtb_13.add(id);
					}
				}
				if(texture>=18)
				{
					q4_gte_18.add(id);
					if(diagnosis.equalsIgnoreCase("m"))
					{
						q4_gtm_18.add(id);
					}
					if(diagnosis.equalsIgnoreCase("b"))
					{
						q4_gtb_18.add(id);
					}
				}
				if(perimeter>=85)
				{
					q5_gte_85.add(id);
					if(diagnosis.equalsIgnoreCase("m"))
					{
						q5_gtm_85.add(id);
					}
					if(diagnosis.equalsIgnoreCase("b"))
					{
						q5_gtb_85.add(id);
					}
				}
				if(area>=500)
				{
					q6_gte_500.add(id);
					if(diagnosis.equalsIgnoreCase("m"))
					{
						q6_gtm_500.add(id);
					}
					if(diagnosis.equalsIgnoreCase("b"))
					{
						q6_gtb_500.add(id);
					}
				}
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//using sets from above write the data to a file
		try {
			//create q3_gte_13 file
			outputStream = new PrintWriter(new FileOutputStream("q3_gte_13.csv",true));
			StringBuilder sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q3_gte_13)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q3_gtm_13 file
			outputStream = new PrintWriter(new FileOutputStream("q3_gtm_13.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q3_gtm_13)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q3_gtb_13 file
			outputStream = new PrintWriter(new FileOutputStream("q3_gtb_13.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q3_gtb_13)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q4_gte_18 file
			outputStream = new PrintWriter(new FileOutputStream("q4_gte_18.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q4_gte_18)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q4_gtm_18 file
			outputStream = new PrintWriter(new FileOutputStream("q4_gtm_18.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q4_gtm_18)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q4_gtb_18 file
			outputStream = new PrintWriter(new FileOutputStream("q4_gtb_18.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q4_gtb_18)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q5_gte_85 file
			outputStream = new PrintWriter(new FileOutputStream("q5_gte_85.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q5_gte_85)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q5_gtm_85 file
			outputStream = new PrintWriter(new FileOutputStream("q5_gtm_85.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q5_gtm_85)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q5_gtb_85 file
			outputStream = new PrintWriter(new FileOutputStream("q5_gtb_85.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q5_gtb_85)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q6_gte_500 file
			outputStream = new PrintWriter(new FileOutputStream("q6_gte_500.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q6_gte_500)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q6_gtm_500 file
			outputStream = new PrintWriter(new FileOutputStream("q6_gtm_500.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q6_gtm_500)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create q6_gtb_500 file
			outputStream = new PrintWriter(new FileOutputStream("q6_gtb_500.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: q6_gtb_500)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create subsetMResult file
			outputStream = new PrintWriter(new FileOutputStream("subsetMResult.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			Set<String> temp = new HashSet<>(q3_gtm_13);
			temp.addAll(q4_gtm_18);
			temp.addAll(q5_gtm_85);
			temp.addAll(q6_gtm_500);
			subsetMResult.addAll(temp);
			for(String s: subsetMResult)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create newResult file
			outputStream = new PrintWriter(new FileOutputStream("newResult.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			temp = new HashSet<>(q3_gte_13);
			temp.retainAll(q4_gte_18);
			temp.retainAll(q5_gte_85);
			temp.retainAll(q6_gte_500);
			newResult.addAll(temp);
			for(String s: newResult)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create originalResult file
			outputStream = new PrintWriter(new FileOutputStream("originalResult.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: originalResult)
			{
				if(!newResult.contains(s)) 
				{
					difference_2.add(s);
				}
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create difference_1 file
			outputStream = new PrintWriter(new FileOutputStream("difference_1.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			subsetMResult.removeAll(newResult);
			difference_1.addAll(subsetMResult);
			for(String s: difference_1)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
			//create difference_2 file
			outputStream = new PrintWriter(new FileOutputStream("difference_2.csv",true));
			sb = new StringBuilder();
			sb.append(label+"\n");
			for(String s: difference_2)
			{
				String alt = completeDataSet.get(s).toString();
				sb.append(alt+"\n");
			}
			outputStream.print(sb);
			outputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	

}
