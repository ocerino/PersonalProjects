import java.io.*;
import java.util.*;

public class Driver {

	public static void main(String[] args) 
	{
		//created an double that can easily be changed to different values to test
		double n = 10000;
		float start=0, end=0;
		
//		//Integer Insertions
//		//Create a tree of integers
//		BST<Integer> intTree = new BST<>();
//		//Test 1: Insert the values from 0 to n in ascending order
//		start=System.currentTimeMillis();
//		for(int i = 0; i< n; i++)
//		{
//			intTree.add(i);
//		}
//		end=System.currentTimeMillis();
//		System.out.println("Test 1 Time:\t" + (end-start)/n);
//		//Create new tree to run second test on
//		intTree = new BST<>();
//		//Test 2: Insert n random values into a tree
//		start=System.currentTimeMillis();
//		for(int i = 0; i< n; i++)
//		{
//			intTree.add((int)(Math.random()*n));
//		}
//		end=System.currentTimeMillis();
//		System.out.println("Test 2 Time:\t" + (end-start)/n);
//		// The second test runs faster than the first. This is because the first test has to check if the number exists,
//		//which it doesn't since every number is bigger than the previous so it has to keep adding to the list for n times.
//		//The second test, however, has to check to see if the number exists in the set which it possibly can since the set is
//		//random. This causes the test to take less time since it might not have to insert a node with 
		
		
		//String Insertions
		//Create a tree of strings
		BST<String> stringTree = new BST<>();
		//created a string to easily insert the words into and a scanner to use to get input from the file
		String book;
		Scanner inputStream = null;
		//Test 1: War and Peace
		start=System.currentTimeMillis();
		for(int i = 0; i<n;i++)
		{
			stringTree = new BST<>();
			try {	
				inputStream = new Scanner(new FileInputStream("warAndPeace.txt"));
				while(inputStream.hasNext())
				{
					book = inputStream.next();
					stringTree.add(book);
				}
			}
			catch (FileNotFoundException e) 
			{
				System.out.println(e.getMessage());
				System.exit(0);			
			}
		inputStream.close();
		}
		end=System.currentTimeMillis();
		System.out.println("Test 1 Time:\t" + (end-start)/n);
		
		//Test 2: Dictionary
		start=System.currentTimeMillis();
		for(int i =0; i<n;i++)
		{
			stringTree = new BST<>();
			try {	
				inputStream = new Scanner(new FileInputStream("wordlist.txt"));
				while(inputStream.hasNext())
				{
					book = inputStream.next();
					stringTree.add(book);
				}
			}
			catch (FileNotFoundException e) 
			{
				System.out.println(e.getMessage());
				System.exit(0);			
			}
		inputStream.close();
		}
		end=System.currentTimeMillis();
		System.out.println("Test 2 Time:\t" + (end-start)/n);
	}

}
