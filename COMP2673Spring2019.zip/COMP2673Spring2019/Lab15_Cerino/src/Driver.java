import java.util.*;
import java.io.*;

public class Driver {

	public static void main(String[] args) 
	{
		try 
		{
			mostCommonPrefix("dictionary.txt", 4);
		}
		catch (IOException e) {
			e.getMessage();
		}
	}

	public static void mostCommonPrefix(String filename, int length) throws IOException 
	{
		//create a scanner to read from file
		Scanner input = new Scanner(new FileInputStream(filename));
		
		//create a map to store the data
		HashMap<String, Integer> dictionary = new HashMap<>();
		
		while (input.hasNext()) 
		{
			//reads the data from the scanner one word at a time
			String word = input.next();
			//converts each word into a key in the map and updates the data
			if(word.length()>length)
			{
				if(!dictionary.containsKey(word.substring(0, length)))
				{
					dictionary.put(word.substring(0, length), 1);
				}
				else
				{
					dictionary.put(word.substring(0, length), dictionary.get(word.substring(0, length)) +1);	
				}
			}
		}
		input.close();
		
		//iterates through the Map to find the prefix that occurred most often
		String mostComPre = "";
		for(Map.Entry<String, Integer> e: dictionary.entrySet())
		{
			if(mostComPre=="")
			{
				mostComPre=e.getKey();
			}
			if(e.getValue().compareTo(dictionary.get(mostComPre))>0)
			{
				mostComPre=e.getKey();
			}
		}
		
		//prints the prefix
		System.out.println("The most common prefix of size " + length+ " is: " + mostComPre + ", which occured "+ dictionary.get(mostComPre)+ " times.");
	}

}
