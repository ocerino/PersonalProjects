
public class SinglyLinkedList <T>
{
	private Node head;
	private Node tail;
	private int size;
	
	public SinglyLinkedList()
	{
		head = null;
		tail = null;
		size = 0;
	}
	
	public void insertAtHead(T v)
	{
		//1: Create a node with value v and next points to head
		Node newNode = new Node(v,head);
		
		//Set tail reference if this is the first node in the list
		if(head == null)
		{
			tail = newNode;
		}
		
		//2: Change head to point to the new node
		head = newNode;
		//3: increase size
		size++;
	}
	
//	public T max()
//	{
//		//checks to see if list is empty
//		if(head == null)
//		{
//			throw new NullPointerException("List is empty!");
//		}
//		//creates a temp node and sets the return value to temp's value
//		Node temp = head;
//		T returnValue = temp.value;
//		//checks to see if there is only one node in the list
//		if(head.next==null)
//		{
//			return returnValue;
//		}
//		//Goes through list of multiple nodes and determines what is the max value in the list and returns it
//		else
//		{
//			while(temp.next!=null)
//			{
//				if(returnValue.compareTo(temp.value)<0)
//				{
//					returnValue = temp.value;
//				}
//				temp = temp.next;
//			}
//			return returnValue;
//		}
//		
//	}
//	
//	public T min()
//	{
//		//Checks to make sure list isn't null
//		if(head == null)
//		{
//			throw new NullPointerException("List is empty!");
//		}
//		//creates a temp node and sets return value to temp's value
//		Node temp = head;
//		T returnValue = temp.value;
//		
//		//Checks to see if there is only one node in the list
//		if(head.next==null)
//		{
//			return returnValue;
//		}
//		//Goes through list if there are multiple nodes and determines the min and returns that value
//		else
//		{
//			while(temp.next!=null)
//			{
//				if(returnValue.compareTo(temp.value)>0)
//				{
//					returnValue = temp.value;
//						
//				}
//				temp = temp.next;
//			}
//			return returnValue;
//		}
//		
//	}
	
	public T deleteHead()
	{
		if(head == null)
		{
			throw new NullPointerException("List is empty!");
		}
		//Store head value in a variable to return
		T returnValue = head.value;
		
		//Set tail reference if this the only noed in the list
		if(head == tail)
		{
			tail = null;
		}
		
		//Move head to the next node
		head = head.next;
		
		//decrease size
		size--;
		
		return returnValue;
	}
	
	public T removeLast()
	{
		Node temp = head;
		T returnValue = temp.value;
		if(head == null)
		{
			throw new NullPointerException("List is empty!");
		}
		if(temp.next == null)
		{
			head = null;
			size--;
		}
		else 
		{
			while(temp.next.next != null)
			{
				temp = temp.next;
			}
	
			//Set temp's next to null
			returnValue = temp.next.value;
			temp.next = null;
			size--;
		}
		return returnValue;
	}
	
	public void insertAtTail(T v)
	{
		//1: Create a new node
		Node newNode = new Node(v, null);
		//Case 1: list is empty
		if(head == null)
		{
			head = newNode;
			tail = newNode;
		}
		else
		{
			tail.next = newNode;
			tail = newNode;
			
		}
		//increase size
		size++;
	}
	
	public int size()
	{
		return size;
	}
	
	public boolean remove(T e)
	{
		Node temp = head;
		if(head!=null)
		{
			if(head.value.equals(e))
			{
				deleteHead();
				return true;
			}
		}
		for(int i = 0; i<size;i++)
		{
			if(temp == null)
			{
				return false;
			}
			if(temp.next!=null&&temp.next.value.equals(e))
			{
				temp.next = temp.next.next;
				size--;
				return true;
			}
			temp = temp.next;
		}
		
		
		return false;
	}
	
	public String toString()
	{
		String s = "List: ";
		//Go through the list and append nodes to s
		Node temp = head;
		while(temp != null)
		{
			s += temp + " ";
			temp = temp.next;
		}
		return s;
	}
	
	private class Node
	{
		private T value;
		private Node next;
		
		public Node (T v, Node n)
		{
			value = v;
			next = n;
		}
		
		public String toString()
		{
			String s = "";
			s += value;
			return s;
		}
	}

	
}
