
public class Driver {

	public static void main(String[] args) {
		
		GameCharacter p1 = new GameCharacter("Samus");
		GameCharacter p2 = new GameCharacter("Link");
		GameCharacter p3 = new GameCharacter("Kirby");
		GameCharacter p4 = new GameCharacter("Mario");
		GameCharacter p5 = new GameCharacter("Rayman");
		
		//singly linked list test code
		SinglyLinkedList<GameCharacter> sList = new SinglyLinkedList<GameCharacter>();
		
		System.out.println(sList.remove(p1));
		
		sList.insertAtHead(p1);
		System.out.println(sList.remove(p1));
		
		sList.insertAtHead(p1);
		sList.insertAtTail(p2);
		sList.insertAtTail(p3);
		sList.insertAtTail(p4);
		sList.insertAtTail(p1);
		System.out.println(sList.remove(p1));
		System.out.println(sList.remove(p4));
		System.out.println(sList.remove(p5));
		System.out.println(sList.remove(p1));
		System.out.println(sList.remove(p2));
		System.out.println(sList.remove(p3));
		
		System.out.println("Ends singly list code");
		
		//doubly linked list test code
		DoublyLinkedList<GameCharacter> dList = new DoublyLinkedList<GameCharacter>();
		
		System.out.println(dList.remove(p1));
		
		dList.insertFirst(p1);
		System.out.println(dList.remove(p1));
		
		dList.insertFirst(p1);
		dList.insertLast(p2);
		dList.insertLast(p3);
		dList.insertLast(p4);
		dList.insertLast(p1);
		System.out.println(dList.remove(p1));
		System.out.println(dList.remove(p4));
		System.out.println(dList.remove(p5));
		System.out.println(dList.remove(p1));
		System.out.println(dList.remove(p2));
		System.out.println(dList.remove(p3));
		
	}

}
