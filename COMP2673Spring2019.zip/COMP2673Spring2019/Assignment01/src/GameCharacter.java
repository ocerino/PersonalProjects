
public class GameCharacter 
{
	String charName;

	public GameCharacter(String s) 
	{
		charName = s;
	}

	public String toString() 
	{
		return charName;
	}

	public boolean equals(Object other) 
	{
		if (other == null) 
		{
			return false;
		}

		if (this.getClass() != other.getClass()) 
		{
			return false;
		}

		if (this.charName != ((GameCharacter) other).charName) 
		{
			return false;
		}

		return true;
	}
}
