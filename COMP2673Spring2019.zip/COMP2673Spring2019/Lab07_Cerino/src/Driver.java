import java.util.Iterator;

public class Driver {

	public static void main(String[] args) {
		DoublyLinkedList<Integer> list1 = new DoublyLinkedList<>();
		DoublyLinkedList<Integer> list2 = new DoublyLinkedList<>();
		
		TwoWayIterator<Integer> it = list1.iterator();
		TwoWayIterator<Integer> it2 = list2.iterator();
		
		//tests with lists with no elements
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		while(it2.hasNext())
		{
			System.out.println(it2.next());
		}
		
		while(it.hasPrevious())
		{
			System.out.println(it.next());
		}
		
		for(int i=0; i < 10; i++)
		{
			list1.insertFirst(i+1);
		}
		
		for(int i=0; i < 20; i++)
		{
			list2.insertFirst(i+1);
		}
		//tests with lists with elements
		System.out.println(list1);
		System.out.println(list2);

		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		while(it2.hasNext())
		{
			System.out.println(it2.next());
		}
		
		while(it.hasPrevious())
		{
			System.out.println(it.previous());
		}
		
		while(it2.hasPrevious())
		{
			System.out.println(it2.previous());
		}
		
		it = list1.iterator();
		it2 = list2.iterator();
		
		System.out.println(list1);
		System.out.println(list2);
		
		
		
		//Foreach loops
		for(Integer i : list1)
		{
			System.out.println("Printed with for each: " + i);
		}
		for(Integer i : list2)
		{
			System.out.println("Printed with for each: " + i);
		}
	}

}
