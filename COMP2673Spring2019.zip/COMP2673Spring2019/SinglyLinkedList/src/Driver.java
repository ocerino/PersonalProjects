
public class Driver {

	public static void main(String[] args) 
	{
		SinglyLinkedList<Integer> test = new SinglyLinkedList<Integer>();
		
		
		test.insertAtHead(1);
		System.out.println(test);
		
		test.insertAtHead(3);
		System.out.println(test);
		
		test.insertAtTail(9);
		System.out.println(test);
		
		test.insertAtTail(4);
		System.out.println(test);

		System.out.println("The max value is: " + test.max());
		System.out.println("The min value is: " + test.min());
		
		System.out.println("the node's value that was removed was: " + test.removeLast());
		System.out.println(test);
		System.out.println("the node's value that was removed was: " + test.deleteHead());
		System.out.println(test);
		System.out.println("the node's value that was removed was: " + test.removeLast());
		System.out.println(test);
		System.out.println("the node's value that was removed was: " + test.removeLast());
		System.out.println(test);
	}

}
