import java.util.Iterator;

public class SinglyLinkedList<E> implements Iterable<E>
{
	private Node head;
	private Node tail;
	
	private int size;
	
	public SinglyLinkedList()
	{
		head = null;
		tail = null;
		size = 0;
	}
	
	public void insertAtHead(E v)
	{
		//1: Create a node with value v and next points to head
		Node newNode = new Node(v, head);
		
		//Set tail reference if this is the first node in the list
		if(head == null)
		{
			tail = newNode;
		}
		//2: Change head to point to the new node
		head = newNode;
		
		//3: increase size
		size++;
	}
	
	public E deleteHead()
	{
		if(head == null)
		{
			throw new IllegalStateException("List is empty!");
		}
		
		//Store head value in a variable to return
		E valueToReturn = head.value;
		
		//Set tail reference if this is the only node in the list
		if(head == tail)
		{
			tail = null;
		}
		
		//Move head to the next node
		head = head.next;
		
		//decrease size
		size--;
		
		return valueToReturn;
	}
	
	public void insertAtTail(E v)
	{
		//1 : Create a new node
		Node newNode = new Node(v, null);
		
		//Case 1: list is empty
		if(head == null)
		{
			head = newNode;
			tail = newNode;
		}
		//Case 2: list is not empty
		else
		{
			tail.next = newNode;
			tail = newNode;
		}
		
		//Increase size
		size++;
	}
	
	public int size()
	{
		return size;
	}
	
	public String toString()
	{
		String s = "List: ";
		//Go through the list and append nodes to s
		Node temp = head;
		while(temp != null)
		{
			s += temp + " ";
			temp = temp.next;
		}
		
		return s;
	}
	
	
	private class Node
	{
		private E value;
		private Node next;
		
		public Node(E v, Node n)
		{
			value = v;
			next = n;
		}
		
		public String toString()
		{
			return value.toString();
		}		
	}


	public Iterator<E> iterator()
	{
		return new SinglyLinkedListIterator();
	}
	
	private class SinglyLinkedListIterator implements Iterator<E>
	{

		private Node cursor;
		private Node prev;
		
		
		public SinglyLinkedListIterator()
		{
			cursor = null;
			prev = null;
		}
		public boolean hasNext() 
		{
			return size > 0 && ((cursor == null && head != null) || cursor.next != null);
		}

		public E next() 
		{
			if(cursor == null)
			{
				cursor = head;
				return cursor.value;
			}
			prev = cursor;
			cursor = cursor.next;
			return cursor.value;
		}
		
		public void remove()
		{
			if(cursor == prev)
			{
				throw new IllegalStateException("Cannot remove without calling next");
			}
			//Case 1: node to be deleted is the head of the list
			if(cursor == head)
			{
				deleteHead();
			}
			else
			{
				prev.next = cursor.next;
				size--;
			}

			cursor = prev;

		}
		
	}

}
