import java.util.Iterator;

public class Driver {

	public static void main(String[] args)
	{
		SinglyLinkedList<Integer> list = new SinglyLinkedList<>();
		
		Iterator<Integer> it = list.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		for(int i=0; i < 10; i++)
		{
			list.insertAtHead(i+1);
		}
		
		System.out.println(list);
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		it = list.iterator();
		while(it.hasNext())
		{
			if(it.next() % 2 == 0)
			{
				it.remove();
			}
		}
		
		System.out.println(list);
		
		
		//Foreach loop
		for(Integer i : list)
		{
			System.out.println("Printed with for each: " + i);
		}


	}

}
