//Name:Oscar Cerino
//Date:April 28th
public class Driver 
{

	public static void main(String[] args) 
	{
		float start=0, end=0;
		//tests depth first search method
		start=System.currentTimeMillis();
		//runs depth search 100 times because that was the smallest number that gave me a time for both methods
		for(int i = 0; i <100; i++)
		{
		System.out.println("Depth Search: " + FireProbability.highestDensityDFS());
		}
		end=System.currentTimeMillis();
		System.out.println("DFS Time:\t" + (end-start)/100.0);
		
		//tests breadth first search method
		start=System.currentTimeMillis();
		//runs breadth search 100 times because that was the smallest number that gave me a time for both methods
		for(int i = 0; i <100; i++)
		{
		System.out.println("Breadth Search: " + FireProbability.highestDensityBFS());
		}
		end=System.currentTimeMillis();
		System.out.println("BFS Time:\t" + (end-start)/100.0);
		
	}
	//The depth first search method is faster than breadth search. This is due to the Stack we implemented in the depth first method because once it has spread the fire to a tree
	//it goes on until it can't spread anymore or gets to the bottom, where the breadth doesn't do this since it has a Queue implemented instead.

}
