//Name:Oscar Cerino
//Date:April 28th
public class FireProbability {
	public static double probabilityOfFireSpreadDFS(double d) {
		int fireSpreadCount = 0;
		for (int i = 0; i < 10000; i++) {
			// create a forest f of size 20x20 with density d
			Forest f = new Forest(20, 20, d);
			if (f.depthFirstSearch()) {
				fireSpreadCount++;
			}
		}
		// the probability of fire spreading in forests of density "d" is:
		return fireSpreadCount / 10000;
	}

	public static double probabilityOfFireSpreadBFS(double d) {
		int fireSpreadCount = 0;
		for (int i = 0; i < 10000; i++) {
			// create a forest f of size 20x20 with density d
			Forest f = new Forest(20, 20, d);
			if (f.breadthFirstSearch()) {
				fireSpreadCount++;
			}
		}
		// the probability of fire spreading in forests of density "d" is:
		return fireSpreadCount / 10000;
	}

	public static double highestDensityDFS() {
		double lowDensity = 0.0;
		double highDensity = 1.0;
		double density = 0.0;
		for (int i = 0; i < 20; i++) {
			// check the midpoint
			density = (highDensity + lowDensity) / 2.0;

			// get probability of fire spreading in forests of 'density'
			double p = probabilityOfFireSpreadDFS(density);

			// check probability of fire spreading
			if (p < 0.5) {
				// low probability: density can be increase
				lowDensity = density;
			} else {
				// high probability: density should be decreased
				highDensity = density;
			}
		}
		// the last value of "density" is the value we seek
		return density;
	}

	public static double highestDensityBFS() {
		double lowDensity = 0.0;
		double highDensity = 1.0;
		double density = 0.0;
		for (int i = 0; i < 20; i++) {
			// check the midpoint
			density = (highDensity + lowDensity) / 2.0;

			// get probability of fire spreading in forests of 'density'
			double p = probabilityOfFireSpreadBFS(density);

			// check probability of fire spreading
			if (p < 0.5) {
				// low probability: density can be increase
				lowDensity = density;
			} else {
				// high probability: density should be decreased
				highDensity = density;
			}
		}
		// the last value of "density" is the value we seek
		return density;
	}

}
