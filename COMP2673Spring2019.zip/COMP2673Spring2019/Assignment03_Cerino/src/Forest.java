import java.util.*;

//Name:Oscar Cerino
//Date:April 28th
public class Forest {
	// 2-d int array forest and 2 ints for height and width of forest array
	private int[][] forest;
	private int height, width;

	// constructor for forest
	public Forest(int h, int w, double d) {
		height = h;
		width = w;
		forest = new int[height][width];
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				if (d<Math.random()) {
					forest[i][j] = 0;
				} else {
					forest[i][j] = 1;
				}
			}
		}

	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < forest.length; i++) {
			for (int j = 0; j < forest[i].length; j++) {
				sb.append(forest[i][j] + " ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	public boolean depthFirstSearch() {
		Position currentPos;
		Stack<Position> cellsToExplore = new Stack<Position>();

		for (int i = 0; i < forest.length; i++) {
			if (forest[0][i] == 1) {
				forest[0][i] = 2;
				Position position = new Position(0, i);
				cellsToExplore.push(position);
			}
		}

		while (!cellsToExplore.isEmpty()) {

			currentPos = cellsToExplore.pop();

			if (currentPos.y == height - 1) {
				return true;
			}

			//check the cell above
			if (currentPos.y > 0) {
				if (forest[currentPos.y - 1][currentPos.x] == 1) {
					Position pos = new Position(currentPos.y - 1, currentPos.x);
					cellsToExplore.push(pos);
					forest[currentPos.y - 1][currentPos.x] = 2;
				}
			}

			//check the cell to the right
			if (currentPos.x < width - 1) {
				if (forest[currentPos.y][currentPos.x + 1] == 1) {
					Position pos = new Position(currentPos.y, currentPos.x + 1);
					cellsToExplore.push(pos);
					forest[currentPos.y][currentPos.x + 1] = 2;
				}
			}

			//check the cell to the left
			if (currentPos.x > 0) {
				if (forest[currentPos.y][currentPos.x - 1] == 1) {
					Position pos = new Position(currentPos.y, currentPos.x - 1);
					cellsToExplore.push(pos);
					forest[currentPos.y][currentPos.x - 1] = 2;
				}
			}
			//check the cell below
			if (currentPos.y < height - 1) {
				if (forest[currentPos.y + 1][currentPos.x] == 1) {
					Position pos = new Position(currentPos.y + 1, currentPos.x);
					cellsToExplore.push(pos);
					forest[currentPos.y + 1][currentPos.x] = 2;
				}
			}

		}
		return false;

	}

	public boolean breadthFirstSearch() {
		Position currentPos;

		Queue<Position> cellsToExplore = new LinkedList<Position>();

		for (int i = 0; i < forest.length; i++) {
			if (forest[0][i] == 1) {
				forest[0][i] = 2;
				Position pos = new Position(0, i);
				cellsToExplore.add(pos);
			}
		}
		int i = 0;
		while (cellsToExplore.isEmpty() == false) {
			i++;
			currentPos = cellsToExplore.remove();

			if (currentPos.y == height - 1) {
				return true;
			}

			//check the cell above
			if (currentPos.y > 0) {
				if (forest[currentPos.y - 1][currentPos.x] == 1) {
					Position pos = new Position(currentPos.y - 1, currentPos.x);
					cellsToExplore.add(pos);
					forest[currentPos.y - 1][currentPos.x] = 2;
				}
			}

			//check the cell to the right
			if (currentPos.x < width - 1) {
				if (forest[currentPos.y][currentPos.x + 1] == 1) {
					Position pos = new Position(currentPos.y, currentPos.x + 1);
					cellsToExplore.add(pos);
					forest[currentPos.y][currentPos.x + 1] = 2;
				}
			}

			//check the cell to the left
			if (currentPos.x > 0) {
				if (forest[currentPos.y][currentPos.x - 1] == 1) {
					Position pos = new Position(currentPos.y, currentPos.x - 1);
					cellsToExplore.add(pos);
					forest[currentPos.y][currentPos.x - 1] = 2;
				}
			}
			//check the cell below
			if (currentPos.y < height - 1) {
				if (forest[currentPos.y + 1][currentPos.x] == 1) {
					Position pos = new Position(currentPos.y + 1, currentPos.x);
					cellsToExplore.add(pos);
					forest[currentPos.y + 1][currentPos.x] = 2;
				}
			}

		}
		return false;

	}

	// made a private class position.
	// takes in a x and a y location from the 2d array and makes it one package.
	private class Position {
		private int x;
		private int y;

		public Position(int xPos, int yPos) {
			x = xPos;
			y = yPos;
		}
	}
}
