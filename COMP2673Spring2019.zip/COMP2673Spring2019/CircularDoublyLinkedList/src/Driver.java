public class Driver 
{

	public static void main(String[] args)
	{
		CircularDoublyLinkedList<Integer> test = new CircularDoublyLinkedList<Integer>();
		
		for(int i =0; i<10;i++)
		{
			test.addAfterCursor(i+1);
			System.out.println(test);
		}
		while(test.size() >0)
		{
			test.advanceCursor((int) (Math.random()*4+1));
			System.out.println("the number being deleted is: " +test.getValue());
			test.deleteCursor();
		}

	}

}
