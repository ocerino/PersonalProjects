public class CircularDoublyLinkedList <T>
{
	//Node Class
	private class Node
	{
		private T value;
		private Node next;
		private Node prev;
		
		public Node (T v, Node n, Node p)
		{
			value = v;
			next = n;
			prev = p;
		}
		
		public String toString()
		{
			return value.toString();
		}
	}
	
	private Node cursor;
	private int size;
	
	public CircularDoublyLinkedList()
	{
		cursor = null;
		size = 0;
	}
	
	public void addAfterCursor(T value)
	{
		//Checks if list is empty and then appropriately adds a new node
		if(cursor == null)
		{
			Node newNode = new Node(value,null,null);
			newNode.next = newNode;
			newNode.prev = newNode;
			cursor = newNode;
			size++;
		}
		//if list isn't empty makes a new node whose prev is the cursor and next is cursor's next
		//and makes cursor's next the new node and cursor's next's prev the new node
		else
		{

			Node newNode = new Node(value,cursor.next,cursor);
			cursor.next.prev = newNode;
			cursor.next = newNode;
			size++;
		}
		
	}
	
	public T deleteCursor()
	{
		//Checks to see if list is empty
		if(cursor==null)
		{
			throw new NullPointerException("List is empty!");
		}
		//Sets the return value to cursor's value
		T returnValue = cursor.value;
		//if there is only one node in the list makes the cursor null
		if(cursor.next == cursor)
		{
			cursor = null;
			size--;
		}
		//Otherwise it makes the appropriate changes to the nodes before and after the cursor and deletes the cursor
		else
		{
			cursor.next.prev = cursor.prev;
			cursor.prev.next = cursor.next;
			cursor = cursor.next;
			size--;
		}
		return returnValue;
	}
	
	public void advanceCursor(int n)
	{
		//advances the cursor n times
		for(int i = 0;i<n;i++)
		{
			cursor = cursor.next;
		}
	}
	
	public T getValue()
	{
		//checks to see if list is null
		if(cursor == null)
		{
			throw new NullPointerException("List is empty!");
		}
		return cursor.value;
	}
	
	public int size()
	{
		return size;
	}
	
	public String toString()
	{
		String s ="List: ";
		
		Node temp = cursor.next;
		while(temp != cursor)
		{
			s += temp + " ";
			temp = temp.next;
		}
		s += cursor + " ";
		return s;
	}
}
