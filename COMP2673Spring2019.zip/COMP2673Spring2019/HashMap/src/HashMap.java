import java.math.BigInteger;
import java.util.*;
import java.util.LinkedList;
import java.util.Map.Entry;

public class HashMap<K, V> implements Map<K, V> {
	private int size;
	private LinkedList<Entry<K, V>>[] theMap;

	private int N; // Number of buckets
	private int p; // Prime that is less than number of buckets
	private int a; // Random number in range (0,p)
	private int b; // Random number in range [0,p)

	public HashMap() 
	{
		initMap(16);

	}

	private int bucketIndex(K key) 
	{
		return (Math.abs(key.hashCode() * a + b) % p) % N;
	}

	private void initMap(int s) 
	{
		N = (new BigInteger(Integer.toString(s))).nextProbablePrime().intValue();
		p = (new BigInteger(Integer.toString(N))).nextProbablePrime().intValue();
		a = (int) (Math.random() * (p - 1) + 1);
		b = (int) (Math.random() * p);

		theMap = (LinkedList<Entry<K, V>>[]) new LinkedList[N];

		for (int i = 0; i < N; i++) {
			theMap[i] = new LinkedList<>();
		}

		size = 0;
	}

	public int size() 
	{
		return size;
	}

	public boolean isEmpty() 
	{
		return size == 0;
	}

	public V get(K key) 
	{
		int index = bucketIndex(key);
		LinkedList<Entry<K, V>> bucket = theMap[index];

		for (Entry<K, V> entry : bucket) {
			if (entry.getKey().equals(key)) {
				return entry.getValue();
			}
		}

		return null;
	}

	public V remove(K key) 
	{
		int index = bucketIndex(key);
		LinkedList<Entry<K, V>> bucket = theMap[index];
		
		Iterator<Entry<K,V>> it = bucket.iterator();
		
		while(it.hasNext())
		{
			Entry<K,V> entry = it.next();
			if(it.next().getKey().equals(key))
			{
				V oldValue = entry.getValue();
				it.remove();
				size--;
				return oldValue;
			}
		}
		
		return null;
	}

	public V put(K key, V value) 
	{
		int index = bucketIndex(key);
		LinkedList<Entry<K, V>> bucket = theMap[index];

		for (Entry<K, V> entry : bucket) 
		{
			if (key.equals(entry.getKey())) 
			{
				return entry.setValue(value);
			}
		}
		bucket.add(new MapEntry(key, value));
		size++;
		expandIfNeeded();
		return null;
	}

	private void expandIfNeeded() 
	{
		if ((double) size / theMap.length > 0.75) 
		{
			Iterable<Entry<K, V>> entrySet = this.entrySet();
			initMap(N * 2);

			for(Entry<K,V> entry: entrySet)
			{
				this.put(entry.getKey(), entry.getValue());
			}
		}
	}

	public Iterable<K> keySet() 
	{ 
		ArrayList<K> keys = new ArrayList<>();
		
		for(Entry<K,V> e: this.entrySet()) 
		{
			keys.add(e.getKey());
		}
		return keys;
	}

	public Iterable<V> valueSet() 
	{
		ArrayList<V> values = new ArrayList<>();
		
		for(Entry<K,V> e: this.entrySet()) 
		{
			values.add(e.getValue());
		}
		return values;
	}

	public Iterable<Entry<K, V>> entrySet() 
	{
		ArrayList<Entry<K,V>> entries = new ArrayList<>();
		
		for(LinkedList<Entry<K,V>> bucket: theMap)
		{
			for(Entry<K,V> e: bucket)
			{
				entries.add(e);
			}
		}
		return entries;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<theMap.length;i++)
		{
			//if()
			sb.append(i + ": [");
			for(Entry<K,V> entry: theMap[i])
			{
				sb.append(entry.toString()+" ");
			}
			sb.append("]\n");
		}
		return sb.toString();// + "\nLargest Bucket size: " + LargestBucketSize;
	}

	private class MapEntry implements Entry<K, V> 
	{
		private K key;
		private V value;

		public MapEntry(K k, V v) 
		{
			key = k;
			value = v;
		}

		public K getKey() 
		{
			return key;
		}

		public V getValue() 
		{
			return value;
		}

		public V setValue(V newValue) 
		{
			V oldValue = value;
			value = newValue;
			return oldValue;
		}
		
		public String toString()
		{
			return "(" +key+","+value+")";
		}

	}

}
