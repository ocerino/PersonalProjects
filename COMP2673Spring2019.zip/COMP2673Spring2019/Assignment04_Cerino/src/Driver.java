import java.io.*;
import java.util.Scanner;

public class Driver 
{

	public static void main(String[] args) 
	{
		// create a Filesystem object.  
		Filesystem fs = new Filesystem();
		
		fs.mkdir("test1");
		fs.touch("test2");
		System.out.println(fs.ls());
		fs.cd("test1");
		fs.mkdir("test3");
		fs.cd("test3");
		System.out.println(fs.tree());
		fs.pwd();
		fs.pwd();
		
		fs.rm("test2");
		System.out.println(fs.tree());
		fs.rmdir("test1");
		System.out.println(fs.tree());
		
		//You should try to read it from a file called "fs.data" using an ObjectInputStream.  If you can't, use the constructor that creates an empty Filesystem.
		//Create a scanner and connect it to System.in
		//Until the user types quit, listen for the commands above and call the appropriate methods of your filesystem method.  
		//Catch any exceptions that arise so the program doesn't crash
		//Once you exit your main loop, save the filesystem using ObjectOutputStream to the file "fs.data"
	
		//opens the file 
		try {
			FileInputStream fileInputStream= new FileInputStream ("fs.data");
			ObjectInputStream objInputStream= new ObjectInputStream(fileInputStream);
			fs=(Filesystem)objInputStream.readObject();
			fileInputStream.close();
			objInputStream.close();	
		}catch (Exception e) 
		{
			System.out.println(e.getMessage());
			fs= new Filesystem();
		}
		
		//asks the user for inputs 
		Scanner keyboard= new Scanner(System.in);
		String userInput="";
		//checks the inputs 
		while(!userInput.equals("quit"))
		{
			System.out.print("-> ");
			userInput=keyboard.nextLine();
			String[] inputArray=userInput.split(" ");
			if (userInput.equalsIgnoreCase("quit")) 
			{
				keyboard.close();
			}
			else if(userInput.equals("ls"))
			{
				System.out.println(fs.ls());
			}
			else if (userInput.startsWith("mkdir"))
			{
				fs.mkdir(inputArray[1]);
			}
			else if(userInput.startsWith("touch"))
			{
				fs.touch(inputArray[1]);
			}
			else if(userInput.equals("pwd"))
			{
				fs.pwd();
			}
			else if (userInput.startsWith("cd")) 
			{
				try {
					fs.cd(inputArray[1]);

				} catch (Exception e) {
					System.out.println("cd error:" + e.getMessage());
				}
				
			}
			else if(userInput.startsWith("rmdir"))
			{
				try {
				fs.rmdir(inputArray[1]);
				}catch (Exception e) {
					System.out.println("rmdit error: "+ e.getMessage());
				}
			}
			else if(userInput.startsWith("rm"))
			{
				try {
					fs.rm(inputArray[1]);

				} catch (Exception e) {
					System.out.println("rm error: "+ e.getMessage());
				}
			}
			else if(userInput.startsWith("tree"))
			{
				System.out.println(fs.tree());
				
			}
			else
			{
				System.out.println("That command does not exist");
			}
		}
		//writes to the file once it saves
		try {
			FileOutputStream fileout= new FileOutputStream ("fs.data");
			ObjectOutputStream objectout= new ObjectOutputStream(fileout);
			objectout.writeObject(fs);	
			fileout.close();
			objectout.close();
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
