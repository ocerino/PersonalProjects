import java.io.*;
import java.util.*;


public class Filesystem implements Serializable {
	private Node root;
	private Node currentDirectory;

	public Filesystem() {
		root = new Node("", null, true);
		currentDirectory = root;
	}

	public void checkMakeFile(String n) {
		for (Node child : currentDirectory.children()) {
			if (n.equals(child.name)) {
				throw new IllegalArgumentException("File already exists!");
			}
		}
	}

	public String ls() {
		// print all the children of the current directory
		StringBuilder sb = new StringBuilder();
		for (Node child : currentDirectory.children()) {
			sb.append(child + " ");
		}
		return sb.toString();
	}

	public void mkdir(String n) {
		// Add a new directory child node to the current directory.
		// Throw an exception if the name already exists (handled by checkMakeFile
		// method)
		checkMakeFile(n);
		currentDirectory.appendChild(n, true);
	}

	public void touch(String n) {
		// Same, as mkdir, but make a new file, not a directory
		checkMakeFile(n);
		currentDirectory.appendChild(n, false);
	}

	public void pwd() {
		// print the full path name of the current directory starting with root and
		// separate them by slashes.
		Stack<String> path = new Stack<>();
		Node temp = currentDirectory;
		// add each string to a stack
		while (!temp.isRoot()) {
			path.push(temp.name);
			temp = temp.parent;
		}
		// create a StringBuilder object and append the entries in the stack to the
		// StringBuilder.
		StringBuilder sb = new StringBuilder();
		while (!path.isEmpty()) {
			sb.append("/" + path.pop());
		}
		// Print the stringBuilder using its toStringMethod
		System.out.println(sb.toString());
	}

	public void cd(String n) {
		// change the currentDirectory to name.
		// If the currentDirectory doesn't have a child named "name" that is a
		// directory, throw an exception
		if (n.equals("..")) {
			if (currentDirectory.isRoot()) {
				currentDirectory = currentDirectory.parent;
			}
			return;
		}
		for (Node child : currentDirectory.children()) {
			if (child.name.equals(n)) {
				if (child.isDirectory()) {
					currentDirectory = child;

					return;
				} else {
					throw new IllegalArgumentException("Can't change current directory to a file!");
				}
			}
		}
		throw new IllegalArgumentException("A directory with this name does not exist");
	}

	public void rm(String n) {
		// remove the file "name" from the currentDirectory.
		// Throw an exception if it's a directory or does not exist.

		for (Node child : currentDirectory.children()) {
			if (child.name.equals(n)) {
				if (child.isDirectory()) {
					throw new IllegalArgumentException("You can not remove a directory!");
				} else {
					currentDirectory.children().remove(child);
					child = null;
					return;
				}
			}
		}
		throw new IllegalArgumentException("Can't remove a file that doesn't exist!");
	}

	public void rmdir(String n) {
		// remove the directory "name" from the currentDirectory.
		// Throw an exception if it's not a directory, or if it's not empty

		for (Node child : currentDirectory.children()) {
			if (child.name.equals(n)) {
				if (child.isDirectory()) {
					if (child.children().isEmpty()) {
						currentDirectory.children().remove(child);
						child = null;
						return;
					} else {
						throw new IllegalArgumentException("You can't remove a directory that isn't empty!");
					}
				} else {
					throw new IllegalArgumentException("You can't remove a file!");

				}
			}

		}
		throw new IllegalArgumentException("Can't remove a file that doesn't exist!");

	}

	public String tree() {
		// pretty print the tree rooted at currentDirectory.
		// Use a preorder traversal with a helper function like we did in class.
		// The helper function should takes an extra int parameter that says how many
		// tabs to print in front of everything.
		// When you make a recursive call, you should print one more tab than you were
		// before.
		StringBuilder sb = new StringBuilder();
		return toStringRecursive(sb, root, 0);
	}

	private String toStringRecursive(StringBuilder sb, Node root, int level) {
		// Print the root
		for (int i = 0; i < level; i++) {
			sb.append("\t");
		}
		sb.append(root + "\n");

		if (root.children() != null) {
			for (Node child : root.children()) {
				toStringRecursive(sb, child, level + 1);
			}
		}

		return sb.toString();
	}

	private class Node implements Serializable {
		private String name;
		private ArrayList<Node> children;
		private Node parent;
		private boolean isDirectory;

		public Node(String n, Node p, boolean isD) {
			name = n;
			parent = p;
			isDirectory = isD;
			if (isDirectory) {
				children = new ArrayList<>();
			} else {
				children = null;
			}

		}

		private boolean isDirectory() {
			return isDirectory;
		}

		private ArrayList<Node> children() {
			return children;
		}

		private void appendChild(String n, boolean isD) {
			Node newNode = new Node(n, this, isD);
			this.children.add(newNode);
		}

		private boolean isRoot() {
			return parent == null;
		}

		public String toString() {
			return this.name;
		}
	}
}
