
public class ArrayListArithmetic<T> extends DynamicArray<T>
{
	
	public ArrayListArithmetic()
	{
		super();
	}
	
	protected void expandArray()
	{
		T [] temp = (T []) new Object[theArray.length +10000];
		
		for(int i =0; i<theArray.length;i++)
		{
			temp[i] = theArray[i];
		}
		theArray = temp;
	}
	
}
