
public class Driver {

	public static void main(String[] args) {
		// creates the geometric array list and the arithmetic list
		DynamicArray<Integer> geo = new DynamicArray<>();
		ArrayListArithmetic<Integer> arith = new ArrayListArithmetic<>();

		float start1 = 0, start2 = 0, end1 = 0, end2 = 0;

		// adds 1 million elements to each array list and times how long it takes
		// between them
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i < 1000; i++) {
//			for(int j=0; j < 1000000; j++)
//			{
//				geo.add(j);
//			}
//			geo = new DynamicArray<>();
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("Geometric time:\t\t" + (end1 - start1)/1000.0);
//		start2 = System.currentTimeMillis();
//		for (int i = 0; i < 1000; i++) {
//			for(int j=0; j < 1000000; j++)
//			{
//				arith.add(j);
//			}
//			arith = new ArrayListArithmetic<>();
//		}
//		end2 = System.currentTimeMillis();
//		System.out.println("Arithmetic time:\t" + (end2 - start2)/1000.0);

		// adds 2 million elements to each array list and times them
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i <1000 ; i++)
//		{
//			geo = new DynamicArray<>();
//			for(int j=0; j < 2000000; j++)
//			{
//				geo.add(j);
//			}
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("Geometric time:\t\t" + (end1 - start1)/1000.0);
//		start2 = System.currentTimeMillis();
//		for(int i =0;i<1000;i++)
//		{
//			arith = new ArrayListArithmetic<>();
//			for (int j = 0; j < 2000000; j++) 
//			{
//				arith.add(j);
//			}
//		}
//		end2 = System.currentTimeMillis();
//		System.out.println("Arithmetic time:\t" + (end2 - start2)/1000.0);

		// adds 4 million elements to each array list and times them
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i < 1000; i++) 
//		{
//			geo = new DynamicArray<>();
//			for (int j = 0; j < 4000000; j++)
//			{
//				geo.add(i);
//			}
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("Geometric time:\t" + (end1 - start1) / 1000.0);
//		start2 = System.currentTimeMillis();
//		for (int i = 0; i < 1000; i++)
//		{
//			arith = new ArrayListArithmetic<>();
//			for (int j = 0; j < 4000000; j++)
//			{
//				arith.add(j);
//			}
//		}
//		end2 = System.currentTimeMillis();
//		System.out.println("Arithmetic time:\t" + (end2 - start2));

		// adds 8 million elements to each array list and times them
		start1 = System.currentTimeMillis();
		for (int i = 0; i < 1000; i++) {
			geo = new DynamicArray<>();
			for(int j=0; j < 8000000; j++)
			{
				geo.add(j);
			}
		}
		end1 = System.currentTimeMillis();
		System.out.println("Geometric time:\t\t" + (end1 - start1)/1000.0);
		start2 = System.currentTimeMillis();
		for (int i = 0; i < 100; i++) {
			arith = new ArrayListArithmetic<>();
			for(int j=0;j<8000000;j++)
			{
				arith.add(j);
			}
		}
		end2 = System.currentTimeMillis();
		System.out.println("Arithmetic time:\t" + (end2 - start2)/100.0);
		
		//The geometric list is O(1) amortized and the arithmetic list is O(n^2)
	}

}
