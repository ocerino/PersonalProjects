
public class DynamicArray <T> implements List <T> 
{
	
	protected T[] theArray;
	private int size;
	
	public DynamicArray()
	{
		theArray = (T[]) new Object[16];
		size = 0;
	}
	
	public T set(T v, int index) 
	{
		if(index>=size)
		{
			throw new ArrayIndexOutOfBoundsException();
		}
		T returnValue = theArray[index];
		theArray[index] = v;
		return returnValue;
	}

	protected void expandArray()
	{
		T [] temp = (T []) new Object[theArray.length *2];
		
		for(int i =0; i<theArray.length;i++)
		{
			temp[i] = theArray[i];
		}
		theArray = temp;
	}

	public void add(T v, int index) 
	{
		if(index>size)
		{
			throw new ArrayIndexOutOfBoundsException();
		}
		for(int i = size;i>index; i--)
		{
			theArray[i]=theArray[i-1];
		}
		theArray[index] = v;
		size++;
		if(size>= theArray.length)
		{
			expandArray();
		}
	}


	public void add(T v) 
	{
		if(size >= theArray.length)
		{
			expandArray();
		}
		theArray[size] = v;
		size++;
		
	}

	public T get(int index) 
	{
		if(index>=size)
		{
			throw new ArrayIndexOutOfBoundsException();
		}
		return theArray[index];
	}

	public T remove(int index) 
	{
		if(index>=size)
		{
			throw new ArrayIndexOutOfBoundsException();
		}
		T returnValue = theArray[index];
		for(int i = index+1; i<size;i++)
		{
			theArray[i-1]= theArray[i];
		}
		theArray[size-1] = null;
		size--;
		return returnValue;
	}
	
	public int size()
	{
		return size;
	}

	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		for(int i =0; i <size; i++)
		{
			sb.append(theArray[i]+ " ");
		}
		return sb.toString();
	}
	
}
