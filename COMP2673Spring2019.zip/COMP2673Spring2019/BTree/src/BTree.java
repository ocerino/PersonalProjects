import java.util.ArrayList;

public class BTree<T extends Comparable<T>>
{
	private Node root;
	private int t; //minimum branching factor
	private int size;

	public BTree(int minBranching)
	{
		size = 0;
		t = minBranching;
		root = new Node(true);
	}
	
	private int childIndex(T key, Node n)
	{
		int index = 0;
		while(index < n.keys.size()-1 && key.compareTo(n.keys.get(index))>0)
		{
			index++;
		}
		
		if(index == n.keys.size()-1 && key.compareTo(n.keys.get(index))>0)
		{
			index++;
		}
		
		return index;
	}
	
	private boolean contains(T key, Node r)
	{
		if(r.keys.contains(key))
		{
			return true;
		}
		
		if(r.isLeaf)
		{
			return false;
		}

		//get the index of the child node to search next
		int index = childIndex(key,r);
		
		//recursively search in the child node
		return contains(key, r.children.get(index));
	}
	
	public boolean contains(T key)
	{
		return contains(key,root);
	}
	
	private void splitNode(Node child, Node parent, int childOrder)
	{
		Node sibling = new Node(child.isLeaf);
		
		//copy the keys from the child into the sibling
		//from index t to 2t-1
		for(int i =t; i<=2*t-2;i++)
		{
			sibling.keys.add(child.keys.get(i));
		}
		
		//remove the keys that were moved
		for(int i=2*t-2;i>=i;i--)
		{
			child.keys.remove(i);
		}
		
		//move and remove the children if not leaf
		if(!child.isLeaf)
		{
			for(int i =t; i<=2*t-1;i++)
			{
				sibling.children.add(child.children.get(i));
			}
			
			//remove the keys that were moved
			for(int i=2*t-1;i>=i;i--)
			{
				child.children.remove(i);
			}
		}
		
		parent.keys.add(childOrder, child.keys.get(t-1));
		parent.children.add(childOrder, sibling);
	}
	
	public boolean add(T key)
	{
		if(root.isFull())
		{
			Node newRoot = new Node(false);
			newRoot.children.add(root);
			splitNode(root, newRoot, 0);
		}
		
		return add(key, root);
	}
	
	private boolean add(T key, Node r)
	{
		if(r.keys.contains(key))
		{
			return false;
		}
	
		int index = childIndex(key,r);
		if(r.isLeaf)
		{
			r.keys.add(index, key);
			size++;
			return true;
		}
		
		Node child = r.children.get(index);
		if(child.isFull())
		{
			splitNode(child,r, index);
		}
		
		index = childIndex(key,r);
		child= r.children.get(index);
		return add(key, child);
	}
	
	private void stringPreOrder(Node r, StringBuilder sb, int level)
	{
		for(int i=0; i<level; i++)
		{
			sb.append("  ");
		}
		sb.append(r+"\n");
		if(!r.isLeaf)
		{
			for(Node child: r.children)
			{
				stringPreOrder(child, sb, level+1);
			}
		}
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		stringPreOrder(root, sb, 0);
		
		return sb.toString();
	}
	
	private class Node
	{
		private ArrayList<T> keys;
		private ArrayList<Node> children;
		private boolean isLeaf;
		
		public Node(boolean leaf)
		{
			isLeaf = leaf;
			keys = new ArrayList<>();
			if(!isLeaf)
			{
				children = new ArrayList<>();
			}
		}
		
		public boolean isFull()
		{
			return children.size() == 2*t;
		}
		
		public String toString()
		{
			String s = "|";
			for(T key: keys)
			{
				s += key +"|";
			}
			return s;
		}
	}
	
}
