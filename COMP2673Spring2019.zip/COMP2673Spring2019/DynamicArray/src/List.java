
public interface List<T>
{
	public T set(T v, int index);
	public void add(T v, int index);
	public void add(T v);
	public T get(int index);
	public T remove(int index);
	
}
