
public class Driver 
{

	public static void main(String[] args) 
	{
		DynamicArray<Integer> a = new DynamicArray<>();
		
		for(int i = 0;i<20;i++)
		{
			a.add(i);
		}
		System.out.println(a);
		
		a.set(-2, 0);
		System.out.println(a);
		
		a.set(-1, 4);
		System.out.println(a);

		a.set(-3, a.size()-1);
		System.out.println(a);

		a.add(-5, 0);
		System.out.println(a);

		a.add(5,8);
		System.out.println(a);

		a.add(-10,a.size());
		System.out.println(a);

		a.add(-20,a.size()-1);
		System.out.println(a);

		a.remove(0);
		System.out.println(a);

		a.remove(8);
		System.out.println(a);

		a.remove(a.size()-1);
		System.out.println(a);

		
	}

}
