public class DoublyLinkedList <T>
{
	//Node Class
	private class Node
	{
		private T value;
		private Node next;
		private Node prev;
		
		public Node (T v, Node n, Node p)
		{
			value = v;
			next = n;
			prev = p;
		}
		
		public String toString()
		{
			return value.toString();
		}
	}
	
	//Sentinel node references
	private Node header;
	private Node trailer;
	private int size;
	
	public DoublyLinkedList()
	{
		//Temporarily set next of header to null until trailer is created
		header = new Node(null, null, null);
		trailer = new Node(null, null, header);
		//Set header's next to trailer
		header.next = trailer;
		size = 0;
	}
	
	/**
	 * 
	 * @param v is the value we are inserting
	 * @param before is the the node before the new node
	 * @param after is the node after the new node
	 */
	
	private void insertBetween(T v, Node before, Node after)
	{
		//Create a new node and set is next to the after node and set its prev to before node
		Node newNode = new Node (v, after, before);
		//Set prev of after to new node and next of before to new node
		after.prev = newNode;
		before.next = newNode;
		size++;
	}
	
	public void insertFirst(T v)
	{
		insertBetween(v,header,header.next);
	}
	
	public void insertLast(T v)
	{
		insertBetween(v,trailer.prev,trailer);
	}
	
	private T removeBetween(Node before, Node after)
	{
		if(header.next == trailer)
		{
			System.out.println("Error! List is empty!");
			return null;
		}
		//Store value to return
		T returnValue = before.next.value;
		//Set next of before to after and prev of after to before
		before.next = after;
		after.prev = before;
		size--;
		return returnValue;
	}
	
	public T removeFirst()
	{
		return removeBetween(header,header.next.next);
	}
	
	public T removeLast()
	{
		return removeBetween(trailer.prev.prev,trailer);
	}
	
	//returns a string representing the list traversed forward
	public String toString()
	{
		String s ="List: ";
		Node temp = header.next;
		while(temp != trailer)
		{
			s += temp + " ";
			temp = temp.next;
		}
		return s;
	}
	
	//returns a string representing the list traversed backward
	public String toStringBackward ()
	{
		String s ="List Backwards: ";
		Node temp = trailer.prev;
		while(temp != header)
		{
			s += temp + " ";
			temp = temp.prev;
		}
		return s;
	}
	
	public int size()
	{
		return size;
	}
}
