
public class Driver {

	public static void main(String[] args) {
		DoublyLinkedList<Integer> test = new DoublyLinkedList<Integer>();
		
		for(int i = 0; i<10;i++)
		{
			test.insertLast(i+1);
			System.out.println(test.toString());
			System.out.println(test.toStringBackward());
		}
		
		while(test.size() > 0)
		{
			System.out.println("Removed: " + test.removeLast());
			System.out.println(test.toString());
			System.out.println(test.toStringBackward());
		}
		
	}

}
