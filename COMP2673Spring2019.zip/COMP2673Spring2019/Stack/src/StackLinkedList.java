public class StackLinkedList<T> implements Stack<T>
{
	private SinglyLinkedList<T> theStack;


	public void push(T v) 
	{
		theStack.insertAtHead(v);
	}

	public T pop() 
	{
		return theStack.deleteHead();
	}

	public T top() 
	{
		return theStack.head();
	}

	public boolean isEmpty() 
	{
		return theStack.size()==0;
	}

	public int size() 
	{
		return theStack.size();
	}
	
}
