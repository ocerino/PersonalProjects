
public class StackArray<T> implements Stack<T>
{
	
	private int size;
	private T[] theStack;
	
	public StackArray(int capacity)
	{
		size = 0;
		theStack =(T[]) new Object[capacity];
	}
	
	public void push(T v) 
	{
		if(size >= theStack.length)
		{
			throw new StackOverflowError("Stack is full!");
		}
		theStack[size] = v;
		size++;
	}


	public T pop() 
	{
		if(size ==0)
		{
			throw new IllegalStateException("Stack is empty!");
		}
		T returnValue = theStack[size-1];
		theStack[size-1] = null;
		size--;
		return returnValue;
	}


	public T top() 
	{
		if(size ==0)
		{
			throw new IllegalStateException("Stack is empty!");
		}
		return theStack[size-1];
	}

	public boolean isEmpty() 
	{
		return size==0;
	}

	public int size() 
	{
		return size;
	}

	public String toString()
	{
		StringBuilder sb = new StringBuilder("Stack: ");
		for(int i =size-1; i >=0;i--)
		{
			sb.append(theStack[i]+" ");
		}
		return sb.toString();
	}
}
