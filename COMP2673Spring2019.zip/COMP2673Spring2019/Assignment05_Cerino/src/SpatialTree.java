import java.awt.geom.Point2D;
import java.util.*;

public class SpatialTree implements DrawListener {
	private ArrayList<Point2D> query;
	private ArrayList<SpatialTreeNode> tree;
	private Draw canvas;
	private double width, height;
	private Point2D center;
	private SpatialTreeNode root;
	private int size;

	public SpatialTree() {
		width = height = 100;
		canvas = new Draw();
		canvas.setXscale(0, width);
		canvas.setYscale(0, height);
		canvas.addListener(this);
		root = null;
		tree = new ArrayList<>();
		size = 0;
	}

	public void add(Point2D point) {
		root = add(point, root, false);
		size++;
	}

	public ArrayList<Point2D> query(Point2D center, double radius) {
		// Returns a list of all points contained inside the query circle (the distance
		// to center is less than or equal to radius)
		ArrayList<Point2D> q = new ArrayList<>();

		for (SpatialTreeNode n : tree) {
			if (n.getPoint().distance(center) <= radius)
				q.add(n.getPoint());
		}

		return q;

	}

	/*
	 * return the new root of the tree after left rotation x y / \ / \ T1 y => x T3
	 * /\ /\ T2 T3 T1 T2
	 */
	private SpatialTreeNode leftRotate(SpatialTreeNode x) {
		SpatialTreeNode y = x.getRight();
		SpatialTreeNode t2 = y.getLeft();

		boolean temp = y.isX();
		y.setLeft(x);
		y.setIsX(x.isX());
		x.setRight(t2);
		x.setIsX(temp);

		// We MUST recalculate from bottom up
		// So x first then y;
		recalculateHeight(x);
		recalculateHeight(y);

		return y;
	}

	/*
	 * return the new root of the tree after right rotation x y / \ / \ T1 y <= x T3
	 * /\ /\ T2 T3 T1 T2
	 */
	private SpatialTreeNode rightRotate(SpatialTreeNode y) {
		SpatialTreeNode x = y.getLeft();
		SpatialTreeNode t2 = x.getRight();

		boolean temp = x.isX();
		x.setRight(y);
		x.setIsX(y.isX());
		y.setLeft(t2);
		y.setIsX(temp);

		recalculateHeight(y);
		recalculateHeight(x);

		return x;
	}

	/*
	 * Rebalance left rebalances the tree rooted at z if the height of the left
	 * subtree - height of the right subtree is greater than 1 returns the new root
	 * of the subtree after rebalance
	 */
	private SpatialTreeNode rebalanceLeft(SpatialTreeNode z) {
		if (height(z.getLeft()) - height(z.getRight()) > 1) {
			SpatialTreeNode y = z.getLeft();

			// Case left left
			if (height(y.getLeft()) >= height(y.getRight())) {
				z = rightRotate(z);
			}
			// Case left right
			else {
				z.setLeft(leftRotate(y));
				z = rightRotate(z);
			}
		}
		return z;
	}

	private SpatialTreeNode rebalanceRight(SpatialTreeNode z) {
		// If there is imbalance then the right will
		// be greater height than the left
		if (height(z.getRight()) - height(z.getLeft()) > 1) {
			SpatialTreeNode y = z.getRight();

			// Case Right Right
			if (height(y.getRight()) >= height(y.getLeft())) {
				z = leftRotate(z);
			}
			// Case right left
			else {
				z.setRight(rightRotate(y));
				z = leftRotate(z);
			}
		}
		return z;
	}

	/**
	 * 
	 * @param point the point you are trying to add
	 * @param r     root of the subtree in the recursive call
	 * @return root of the subtree after insert is completed
	 */
	private SpatialTreeNode add(Point2D point, SpatialTreeNode r, boolean isY) {
		// We found the place where node needs to be inserted
		if (r == null) {
			r = new SpatialTreeNode(point, r, isY);
			size++;
			tree.add(r);
			return r;
		} else if (r.isX() == false) {
			if (point.getY() == r.getPoint().getY()) {
				tree.add(r);
				return r;
			}

			if (point.getY() < r.getPoint().getY()) {
				r.setLeft(add(point, r.getLeft(), r.isX()));
				recalculateHeight(r);
				r = rebalanceLeft(r);
			}

			if (point.getY() > r.getPoint().getY()) {
				r.setRight(add(point, r.getRight(), r.isX()));
				recalculateHeight(r);
				r = rebalanceRight(r);
			}

			size++;
			tree.add(r);
			return r;
		} else {
			if (point.getX() == r.getPoint().getX()) {
				tree.add(r);
				return r;
			}

			if (point.getX() < r.getPoint().getX()) {
				r.setLeft(add(point, r.getLeft(), r.isX()));
				recalculateHeight(r);
				r = rebalanceLeft(r);
			}

			if (point.getX() > r.getPoint().getX()) {
				r.setRight(add(point, r.getRight(), r.isX()));
				recalculateHeight(r);
				r = rebalanceRight(r);
			}

			size++;
			tree.add(r);
			return r;
		}

	}

	private void recalculateHeight(SpatialTreeNode n) {
		n.setHeight(Math.max(height(n.getLeft()), height(n.getRight())) + 1);
	}

	private int height(SpatialTreeNode n) {
		if (n == null)
			return -1;
		return n.getHeight();
	}

	private void toString(SpatialTreeNode r, StringBuilder sb, int level) {
		if (r != null) {
			// Print the root
			for (int i = 0; i < 2 * level; i++) {
				sb.append(" ");
			}

			// Recursively print the left and right children
			sb.append(r.toString() + "\n");

			toString(r.getLeft(), sb, level + 1);
			toString(r.getRight(), sb, level + 1);
		}
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		toString(root, sb, 0);
		String r = sb.toString();
		r += "Tree height: " + root.getHeight();
		return r;
	}

	public void draw() {
		// Draws the spatial tree using Draw and DrawListener
		// Each node should show the point, and the regions bounding each point (see
		// below). (Hint: use recursion.)
		canvas.clear();
		draw(root, new Point2D.Double(0.0, 500.0), new Point2D.Double(500.0, 0.0));

	}

	private void draw(SpatialTreeNode n, Point2D L, Point2D R) { // draw the tree recursively

		// if node is a x node
		if (n != null && n.isX()) {
			canvas.setPenColor(Draw.BLACK);
			canvas.filledCircle(n.getPoint().getX(), n.getPoint().getY(), .5); // draw the point corresponding to the root
			
			canvas.setPenColor(Draw.RED);
			canvas.line(n.getPoint().getX(), L.getY(), n.getPoint().getX(), R.getY()); // draw vertical line corresponding to the
																			// root

			if (n.getLeft() != null) { // recursively draw left subtree of root
				draw(n.getLeft(), new Point2D.Double(L.getX(), L.getY()), new Point2D.Double(n.getPoint().getX(), R.getY()));
			}
			if (n.getRight() != null) { // recursively draw right subtree of root
				draw(n.getRight(), new Point2D.Double(n.getPoint().getX(), L.getY()), new Point2D.Double(R.getX(), R.getY()));
			}
		}
		// if node is a y node
		if (n != null && !n.isX()) {
			canvas.setPenColor(Draw.BLACK);
			canvas.filledCircle(n.getPoint().getX(), n.getPoint().getY(), .5); // draw the point corresponding to the root

			canvas.setPenColor(Draw.BLUE);
			canvas.line(L.getX(), n.getPoint().getY(), R.getX(), n.getPoint().getY()); // draw horizontal line corresponding to the
																			// root

			if (n.getLeft() != null) { // recursively draw left subtree of root
				draw(n.getLeft(), new Point2D.Double(L.getX(), n.getPoint().getY()), new Point2D.Double(R.getX(), R.getY()));
			}
			if (n.getRight() != null) { // recursively draw right subtree of root
				draw(n.getRight(), new Point2D.Double(L.getX(), L.getY()), new Point2D.Double(R.getX(), n.getPoint().getY()));
			}
		}
	}

	// sets the center point to the x and y position when the mouse is clicked
	public void mousePressed(double x, double y) {
		center = new Point2D.Double(x, y);
		this.draw();
	}

	public void mouseDragged(double x, double y) {
		// TODO Auto-generated method stub

	}

	// determines the radius, creates and runs the query and displays the points
	// that fall within it
	public void mouseReleased(double x, double y) {
		double radius = center.distance(new Point2D.Double(x, y));
		query = this.query(center, radius);
		canvas.setPenColor(Draw.YELLOW);
		for (Point2D p : query) {
			canvas.filledCircle(p.getX(), p.getY(), .5);
		}
	}

	public void keyTyped(char c) {
		// TODO Auto-generated method stub

	}

	public void keyPressed(int keycode) {
		// TODO Auto-generated method stub

	}

	public void keyReleased(int keycode) {
		// TODO Auto-generated method stub

	}

}
