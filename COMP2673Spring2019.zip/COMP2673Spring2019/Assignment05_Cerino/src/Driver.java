import java.awt.geom.Point2D;

public class Driver {
	
	
	public static void main(String[] args) 
	{
		//creates new spatial tree
		SpatialTree test = new SpatialTree();
		
		//adds 100 random points to the tree
		for(int i = 0;i<100;i++)
		{
			Point2D point = new Point2D.Double(Math.random()*100,Math.random()*100);
			test.add(point);
		}
		
		//draws the tree in an infinite loop that allows the user to draw query circles
		test.draw();
	}

}