import java.awt.geom.Point2D;

public class SpatialTreeNode {
	
		private SpatialTreeNode parent;
		private SpatialTreeNode left;
		private SpatialTreeNode right;
		private Point2D point;
		private boolean isX;
		private int height;
		
		public SpatialTreeNode( Point2D p, SpatialTreeNode par, boolean isY)
		{
			parent = par;
			left = null;
			right = null;
			point = p;
			isX = !isY;
			height = 0;
		}
		
		public int getHeight()
		{
			return height;
		}
		
		public void setHeight(int h)
		{
			this.height =h;
		}

		public SpatialTreeNode getLeft() {
			return left;
		}

		public void setLeft(SpatialTreeNode left) {
			this.left = left;
		}

		public SpatialTreeNode getRight() {
			return right;
		}

		public void setRight(SpatialTreeNode right) {
			this.right = right;
		}

		public SpatialTreeNode getParent() {
			return parent;
		}
		
		public Point2D getPoint()
		{
			return point;
		}
		
		public boolean isX()
		{
			return isX;
		}
		
		public void setIsX(boolean b)
		{
			this.isX=b;
		}
		
		public String toString()
		{
			return "is an X node?: " + isX + "; Point value: "+point.toString();
		}

}

