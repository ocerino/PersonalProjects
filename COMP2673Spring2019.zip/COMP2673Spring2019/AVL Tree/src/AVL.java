import java.util.ArrayList;
import java.util.Iterator;


public class AVL<T extends Comparable<T>> implements Set<T> 
{
	private int size;
	private Node root;

	public AVL()
	{
		size = 0;
		root = null;
	}

	/**
	 * Find the node that contains v if it exits. If it doesn't exist
	 * then return the node that would have been the parent of a node
	 * containing v.
	 * @param r root of the subtree
	 * @param v value we are searching for
	 * @return Node containing v or node that would have a parent of v
	 */
	private Node find(Node r, T v)
	{
		//Case 1: Tree is empty
		if(r == null)
		{
			return null;
		}

		//Case 2: r contains v OR r is a leaf 
		if(r.value.equals(v))
		{
			return r;
		}

		//Case 3: r contains a value that is less than v
		if(r.value.compareTo(v) < 0 && r.right != null)
		{
			return find(r.right, v);
		}

		//Case 4: r contains a value that is greater than v
		if(r.value.compareTo(v) > 0 && r.left != null)
		{
			return find(r.left, v);
		}


		//All other cases: I didn't find the value
		return r;

	}

	/* return the new root of the tree after left rotation
	 * 			x               y
	 * 		   / \             / \ 
	 * 		  T1   y  =>     x   T3
	 * 		      /\         /\
	 * 		     T2 T3      T1 T2
	 */
	private Node leftRotate(Node x)
	{
		Node y = x.right;
		Node t2 = y.left;

		y.left = x;
		x.right = t2;

		//We MUST recalculate from bottom up
		//So x first then y;
		recalculateHeight(x);
		recalculateHeight(y);

		return y;
	}


	/* return the new root of the tree after left rotation
	 * 			x               y
	 * 		   / \             / \ 
	 * 		  T1   y    <=    x   T3
	 * 		      /\         /\
	 * 		     T2 T3      T1 T2
	 */
	private Node rightRotate(Node y)
	{
		Node x = y.left;
		Node t2 = x.right;

		x.right = y;
		y.left = t2;

		recalculateHeight(y);
		recalculateHeight(x);

		return x;
	}

	/*
	 * Rebalance left rebalances the tree rooted at z if the height
	 * of the left subtree - height of the right subtree is greater than 1
	 * returns the new root of the subtree after rebalance
	 */
	private Node rebalanceLeft(Node z)
	{
		if(height(z.left) - height(z.right) > 1)
		{
			Node y = z.left;

			//Case left left 
			if(height(y.left) >= height(y.right))
			{
				z = rightRotate(z);
			}
			//Case left right
			else
			{
				z.left = leftRotate(y);
				z = rightRotate(z);
			}
		}
		return z;
	}

	private Node rebalanceRight(Node z)
	{
		//If there is unbalance then the right will
		//be greater height than the left
		if(height(z.right) - height(z.left) > 1)
		{
			Node y = z.right;

			//Case Right Right 
			if(height(y.right) >= height(y.left))
			{
				z = leftRotate(z);
			}
			//Case right left
			else
			{
				z.right = rightRotate(y);
				z = leftRotate(z);
			}
		}
		return z;	
	}



	/**
	 * 
	 * @param k key
	 * @param r root of the subtree in the recursive call
	 * @return root of the subtree after insert is completed
	 */
	private Node add(T v, Node r)
	{
		//We found the place where node needs to be inserted
		if(r == null)
		{
			r = new Node(v);
			return r;
		}

		if(r.value.compareTo(v) == 0)
		{
			return r;
		}

		if(r.value.compareTo(v) > 0)
		{
			r.left = add(v, r.left);
			recalculateHeight(r);
			r = rebalanceLeft(r);
		}

		if(r.value.compareTo(v) < 0)
		{
			r.right = add(v, r.right);
			recalculateHeight(r);
			r = rebalanceRight(r);
		}

		return r;

	}
	/**
	 * Adds a node with the value k if it doesn't exist
	 * @param k value to be inserted
	 * @return true if value was inserted successfully
	 */
	public boolean add(T k) 
	{
		int oldSize = size;
		root = add(k, root);
		return oldSize < size;
	}

	/**
	 * 
	 * @param n node
	 * @return height of the node
	 */
	private int height(Node n)
	{
		if(n == null)
			return -1;
		return n.height;
	}

	private void recalculateHeight(Node n)
	{
		n.height = Math.max(height(n.left), height(n.right)) + 1;
	}

	/**
	 * Remove the node with value v and return the root of the subtree with the node removed
	 * @param r root of the subtree 
	 * @param v value to remove
	 * @return root of the new subtree
	 */
	private Node remove(Node r, T v)
	{
		//Case 1: tree is empty
		if(r == null)
		{
			return null;
		}
		if(r.value.compareTo(v) < 0)
		{
			r.right = remove(r.right, v);
			recalculateHeight(r);
			r = rebalanceLeft(r);
		}
		else if(r.value.compareTo(v) > 0)
		{
			r.left = remove(r.left, v);
			recalculateHeight(r);
			r = rebalanceRight(r);
		}
		else
		{
			size--;
			//Case 1: leaf
			if(r.right == null && r.left == null)
			{
				return null;
			}
			//Case 2: single child
			if(r.right == null)
			{
				return r.left;
			}
			if(r.left == null)
			{
				return r.right;
			}
			//Case 3: two children;
			Node pred = r.left;
			while(pred.right != null)
			{
				pred = pred.right;
			}
			r.value = pred.value;
			r.left = remove(r.left, pred.value);
		}

		return r;

	}

	public boolean remove(T k) 
	{
		int oldSize = size;
		root = remove(root, k);
		return oldSize > size;
	}


	private void toString(Node r, StringBuilder sb, int level)
	{
		if(r != null)
		{
			//Print the root
			for(int i=0; i < 2 * level; i++)
			{
				sb.append(" ");
			}

			//Recursively print the left and right children
			sb.append(r.toString() + "\n");

			toString(r.left, sb, level+1);
			toString(r.right, sb, level+1);
		}
	}

	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		toString(root, sb, 0);
		String r = sb.toString();
		r += "Tree height: " + root.height; 
		return r;
	}


	public boolean contains(T k)
	{
		Node n = find(root, k);
		return n != null && n.value.equals(k);
	}
	private void populateSnapshot(ArrayList<T> snapshot, Node r)
	{
		if(r != null)
		{
			populateSnapshot(snapshot, r.left);
			snapshot.add(r.value);
			populateSnapshot(snapshot, r.right);
		}
	}

	public Iterator<T> iterator()
	{
		ArrayList<T> snapshot = new ArrayList<>();
		populateSnapshot(snapshot, root);
		return snapshot.iterator();
	}

	public void addAll(Set<T> other) 
	{
		for(T element : other)
		{
			this.add(element);
		}
	}

	public void retainAll(Set<T> other) 
	{
		for(T element : this)
		{
			if(!other.contains(element))
			{
				this.remove(element);
			}
		}
	}

	public void removeAll(Set<T> other) 
	{
		for(T element : other)
		{
			this.remove(element);
		}
	}


	private class Node
	{
		private T value;
		private Node left;
		private Node right;
		private int height;

		public Node(T v)
		{
			value = v;
			left = null;
			right = null;
			height = 0;
		}

		public String toString()
		{
			return "(" + height + ")" + value.toString();
		}
	}
}
