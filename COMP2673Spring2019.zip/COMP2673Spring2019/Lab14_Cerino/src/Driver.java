import java.util.*;
import java.io.*;

public class Driver {

	public static void main(String[] args) 
	{
		Set<String> girlNames = new HashSet<String>();
		Set<String> boyNames = new HashSet<String>();
		Set<String> unisexNames = new HashSet<String>();
		
		String name;
		Scanner inputStream = null;
		//goes through list of girl names and adds them to the set of girl names
		try
		{
			inputStream = new Scanner(new FileInputStream("girlNames2016.txt"));
			while(inputStream.hasNext())
			{
				name = inputStream.next();
				girlNames.add(name);
				name = inputStream.next();
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		inputStream.close();

		//goes through list of boy names and adds them to the set of boy names
		try
		{
			inputStream = new Scanner(new FileInputStream("boyNames2016.txt"));
			while(inputStream.hasNext())
			{
				name = inputStream.next();
				boyNames.add(name);
				name = inputStream.next();
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		inputStream.close();
		
		//goes through the set of boy names and checks to see if the names in that set are in the set of girl names
		//and adds the names in common to the set of unisex names
		for(String s: boyNames)
		{
			if(girlNames.contains(s))
			{
				unisexNames.add(s);
			}
		}
		//Prints out the list of unisex names
		System.out.println(unisexNames);
	}

}
