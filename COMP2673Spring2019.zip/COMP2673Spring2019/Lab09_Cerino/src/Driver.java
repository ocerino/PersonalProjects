
public class Driver {

	public static void main(String[] args) 
	{
		BinaryTree<Character> tree = new BinaryTree<>();
		
		tree.addRoot('/');
		tree.addLeft('+', tree.root());
		tree.addRight('-', tree.root());
		tree.addLeft('*', tree.getLeft(tree.root()));
		tree.addRight('3', tree.getLeft(tree.root()));
		tree.addLeft('8', tree.getRight(tree.root()));
		tree.addRight('+', tree.getRight(tree.root()));
		tree.addLeft('6', tree.getLeft(tree.getLeft(tree.root())));
		tree.addRight('2', tree.getLeft(tree.getLeft(tree.root())));
		tree.addLeft('5', tree.getRight(tree.getRight(tree.root())));
		tree.addRight('9', tree.getRight(tree.getRight(tree.root())));
		printExpression(tree, tree.root());
		System.out.print(" = " + evaluateExpression(tree, tree.root()));
	}

	public static void printExpression(BinaryTree<Character> t, Position<Character> p)
	{
		if(t.hasLeft(p))
		{
			System.out.print("(");
			printExpression(t,t.getLeft(p));
		}
		System.out.print(p.getValue());
		if(t.hasRight(p))
		{
			printExpression(t,t.getRight(p));
			System.out.print(")");
		}
	}
	
	public static double evaluateExpression(BinaryTree<Character> t, Position<Character> p)
	{
		Double x = 0.0,y =0.0;
		Character op ='a';
		if(t.isExternal(p))
		{
			return Double.parseDouble(p.getValue().toString());
		}
		else
		{
			x = evaluateExpression(t,t.getLeft(p));
			y = evaluateExpression(t,t.getRight(p));
			op = p.getValue();
			if(op.equals('+'))
			{
				return x + y;
			}
			else if(op.equals('*'))
			{
				return x * y;
			}
			else if(op.equals('-'))
			{
				return x - y;
			}
			else
			{
				return x / y;
			}
		}
		
	}
}
