import java.util.Arrays;

public class Driver {

	public static void main(String[] args) 
	{
		int[] a = new int [25000];
		int[] b = new int [50000];
		int[] c = new int [100000];
		int[] d = new int [200000];
		int[] e = new int [400000];
		float start1 =0,end1=0,start2=0,end2=0,start3=0,end3 =0;
		for(int i =0;i<25000;i++)
		{
			a[i]=(int) (Math.random()*25000 +1);
		}
		for(int i =0;i<50000;i++)
		{
			b[i]=(int) (Math.random()*50000 +1);
		}
		for(int i =0;i<100000;i++)
		{
			c[i]=(int) (Math.random()*100000 +1);
		}
		for(int i =0;i<200000;i++)
		{
			d[i]=(int) (Math.random()*100000 +1);
		}
		for(int i =0;i<400000;i++)
		{
			e[i]=(int) (Math.random()*100000 +1);
		}
		Arrays.sort(a);
		Arrays.sort(b);
		Arrays.sort(c);
		Arrays.sort(d);
		Arrays.sort(e);
		
		//25k elements
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i < 1000; i++) {
//			Search.alg1(a);
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("alg1 time:\t\t" + (end1 - start1)/1000.0);
//		
//		start2 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg2(a);
//		}
//		end2 = System.currentTimeMillis();
//		System.out.println("alg2 time:\t\t" + (end2 - start2)/10000000.0);
//		
//		start3 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg3(a);
//		}
//		end3 = System.currentTimeMillis();
//		System.out.println("alg3 time:\t\t" + (end3 - start3)/10000000.0);
		//50k element array
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i < 1000; i++) {
//				Search.alg1(b);
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("alg1 time:\t\t" + (end1 - start1)/1000.0);
//		
//		start2 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg2(b);
//		}
//		end2 = System.currentTimeMillis();
//		System.out.println("alg2 time:\t\t" + (end2 - start2)/10000000.0);
//		
//		start3 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg3(b);
//		}
//		end3 = System.currentTimeMillis();
//		System.out.println("alg3 time:\t\t" + (end3 - start3)/10000000.0);
		//100k element array
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i < 1000; i++) {
//				Search.alg1(c);
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("alg1 time:\t\t" + (end1 - start1)/1000.0);
//		
//		start2 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg2(c);
//		}
//		end2 = System.currentTimeMillis();
//		System.out.println("alg2 time:\t\t" + (end2 - start2)/10000000.0);
//		
//		start3 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg3(c);
//		}
//		end3 = System.currentTimeMillis();
//		System.out.println("alg3 time:\t\t" + (end3 - start3)/10000000.0);
		//200k element array
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i <10; i++) {
//				Search.alg1(d);
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("alg1 time:\t\t" + (end1 - start1)/10.0);
//		
//		start2 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg2(d);
//		}
//		end2 = System.currentTimeMillis();
//		System.out.println("alg2 time:\t\t" + (end2 - start2)/10000000.0);
//		
//		start3 = System.currentTimeMillis();
//		for (int i = 0; i < 10000000; i++) {
//				Search.alg3(d);
//		}
//		end3 = System.currentTimeMillis();
//		System.out.println("alg3 time:\t\t" + (end3 - start3)/10000000.0);
		//400k element array
//		start1 = System.currentTimeMillis();
//		for (int i = 0; i < 10; i++) {
//				Search.alg1(e);
//		}
//		end1 = System.currentTimeMillis();
//		System.out.println("alg1 time:\t\t" + (end1 - start1)/10.0);
		
		start2 = System.currentTimeMillis();
		for (int i = 0; i < 10000000; i++) {
				Search.alg2(e);
		}
		end2 = System.currentTimeMillis();
		System.out.println("alg2 time:\t\t" + (end2 - start2)/10000000.0);
		
		start3 = System.currentTimeMillis();
		for (int i = 0; i < 10000000; i++) {
				Search.alg3(e);
		}
		end3 = System.currentTimeMillis();
		System.out.println("alg3 time:\t\t" + (end3 - start3)/10000000.0);
		
		//alg1 is O(n^2)
		//alg2 is O(n)
		//alg3 is O(n)
		
	}

}