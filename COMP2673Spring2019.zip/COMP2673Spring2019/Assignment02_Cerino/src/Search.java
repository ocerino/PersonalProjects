
public class Search 
{
	public static boolean alg1(int[] a)
	{
		boolean returnValue = false;
		for(int i =0;i<a.length;i++)
		{
			returnValue = hasNegative(a[i],a);
			if(returnValue == true)
			{
				return returnValue;
			}
		}
		return returnValue;
	}
	
	public static boolean alg2(int[] a)
	{
		int first = 0;
		int last = a.length-1;
		for(int i =0;i<a.length;i++)
		{
			int x = Math.negateExact(a[i]);
			do
			{
				int middle = (first + last)/2;
			    if( a[middle] == x)
			    {
			        return true;
			    }
			    else if( x < a[middle])
			    {
			        last = middle;
			    }else {
			        first = middle + 1;
			    }
			}while(first < last);
		   
		}
		return false;
	}
	
	public static boolean alg3(int[] a)
	{
		int i = 0;
		int j = a.length-1;
		do
		{
			if(a[i] + a[j] == 0)
			{
				return true;
			}
			else if(a[i]+a[j] <0)
			{
				i++;
			}
			else
			{
				j--;
			}
		}while(i<j);
		return false;
	}
	
	private static boolean hasNegative(int x, int [] a)
	{
		for(int i = 0;i<a.length;i++)
		{
			if(Math.negateExact(x) == a[i])
			{
				return true;
			}
		}
		return false;
	}
}
