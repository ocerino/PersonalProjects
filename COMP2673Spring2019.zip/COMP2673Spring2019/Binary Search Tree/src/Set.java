
public interface Set<T> extends Iterable<T>
{
	public boolean contains(T v);
	public boolean remove(T v);
	public boolean add(T v);
	public void addAll(Set<T> other);
	public void retainAll(Set<T> other);
	public void removeAll(Set<T> other);
}
