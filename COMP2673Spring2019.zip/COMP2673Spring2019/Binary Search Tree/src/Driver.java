
public class Driver {

	public static void main(String[] args) 
	{
		BST<Integer> tree = new BST<>();
		
		for(int i = 0; i< 30; i++)
		{
			tree.add((int)(Math.random()*1000));
		}
		
		System.out.println(tree);
	}

}
