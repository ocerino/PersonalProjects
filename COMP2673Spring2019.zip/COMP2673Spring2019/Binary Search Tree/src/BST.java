import java.util.ArrayList;
import java.util.Iterator;

public class BST<T extends Comparable<T>> implements Set<T>, Iterable<T>
{
	private Node root;
	private int size;
	
	public BST()
	{
		root = null;
		size = 0;
	}

	/**
	 * 
	 * @param v value we are searching for
	 * @param r root of the subtree
	 * @return either the node that contains v or the node that would be parent. Return null if tree is empty
	 */
	private Node findNode(T v, Node r)
	{
		//Case 1: Tree is empty
		//This can only be true when the entire tree is empty
		if(r == null)
		{
			return null;
		}
		
		//Case 2: We reached a leaf
		if(r.left == null && r.right == null)
		{
			return r;
		}
		
		//Case 3: I found the value
		if(r.value.compareTo(v) == 0)
		{
			return r;
		}
		if(r.left != null && r.value.compareTo(v) > 0)
		{
			return findNode(v, r.left);
		}
		if(r.right != null && r.value.compareTo(v) < 0)
		{
			return findNode(v, r.right);
		}
		
		return r;
	}
	public boolean contains(T v)
	{
		Node n = findNode(v, root);
		return n != null && n.value.compareTo(v) == 0;
	}

	/**
	 * 
	 * @param v value we are removing
	 * @param r root of the tree from which v is removed
	 * @return root of subtree after remove is done
	 */
	private Node removeNode(T v, Node r)
	{
		//Case 1: Subtree is empty
		if(r == null)
		{
			return null;
		}
		
		//Case 2: value is in the left subtree
		if(r.value.compareTo(v) > 0)
		{
			r.left = removeNode(v, r.left);
			return r;
		}
		if(r.value.compareTo(v) < 0)
		{
			r.right = removeNode(v, r.right);
			return r;
		}
		//We found the node to remove
		else
		{
			//Case 1: r is a leaf
			if(r.left == null && r.right == null)
			{
				size--;
				return null;
			}
			//Case2: r has a left child
			if(r.right == null)
			{
				size--;
				return r.left;
			}
			//Case 2: r has a right child
			if(r.left == null)
			{
				size--;
				return r.right;
			}
			//Case 3: r has two children
			//First walk to the predecessor
			Node pred = r.left;
			while(pred.right != null)
			{
				pred = pred.right;
			}
			//replace r's value with pred value
			r.value = pred.value;
			r.left = removeNode(pred.value, r.left);
			
			return r;
		}
		
		
	}
	public boolean remove(T v) 
	{
		int oldSize = size;
		root = removeNode(v, root);
		return size < oldSize;
	}

	
	public boolean add(T v)	
	{
		Node n = findNode(v, root);
		
		if(n == null)
		{
			root = new Node(v);
			size++;
			return true;
		}
		
		//Value already exists in the set
		if(n.value.compareTo(v) == 0)
		{
			return false;
		}
		
		//Value does not exist in the set and n is the parent
		//Case 1: v will be a left child
		if(n.value.compareTo(v) > 0)
		{
			n.left = new Node(v);
		}
		//Case 2: v will be right child
		else
		{
			n.right = new Node(v);
		}
		size++;
		return true;
	}
	
	private void populateSnapshot(ArrayList<T> snapshot, Node r)
	{
		if(r != null)
		{
			populateSnapshot(snapshot, r.left);
			snapshot.add(r.value);
			populateSnapshot(snapshot, r.right);
		}
	}

	public Iterator<T> iterator()
	{
		ArrayList<T> snapshot = new ArrayList<>();
		populateSnapshot(snapshot, root);
		return snapshot.iterator();
	}

	public void addAll(Set<T> other) 
	{
		for(T element : other)
		{
			this.add(element);
		}
	}

	public void retainAll(Set<T> other) 
	{
		for(T element : this)
		{
			if(!other.contains(element))
			{
				this.remove(element);
			}
		}
	}

	public void removeAll(Set<T> other) 
	{
		for(T element : other)
		{
			this.remove(element);
		}
	}
	
	
	private String toStringRecursive(StringBuilder sb, Node root, int level)
	{
		//Print the root
		for(int i=0; i < level; i++)
		{
			sb.append("\t");
		}
		sb.append(root + "\n");
		
		if(root.left != null)
		{
			toStringRecursive(sb, root.left, level+1);
		}
		if(root.right != null)
		{
			toStringRecursive(sb, root.right, level+1);
		}
		
		return sb.toString();
		
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		return toStringRecursive(sb, root, 0);
	}

	private class Node
	{
		private T value;
		private Node left;
		private Node right;
		
		public Node(T v)
		{
			value = v;
			left = null;
			right = null;
		}
		
		public String toString()
		{
			return value.toString();
		}
	}

}
