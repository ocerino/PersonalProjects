
public class Fib 
{
	
	public static int fib2(int n)
	{
		int[] a = new int[n];
		a[0] = 1;
		a[1] = 1;
		
		for(int i=2; i < a.length; i++)
		{
			a[i] = a[i-1] + a[i-2];
		}
		
		return a[a.length-1];
				
	}
	public static int fib(int n)
	{
		if(n == 1 || n == 2)
		{
			return 1;
		}
		return fib(n-1) + fib(n-2);
		
	}
	
	 public static void main(String[] args)
	  {
		  int expCount = 100;
		  int result = 0;
		  System.out.println("n \t\t Time");
		  for(int n = 2; n < 300000; n++)
		  {
			  long start = System.currentTimeMillis();
			  result = fib2(n);
			  long end = System.currentTimeMillis();
			  System.out.println(n + ","+ (end-start));
		  }
	  }

}
