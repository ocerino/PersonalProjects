
public class StringTesting
{
  public static String makeStars(int n)
  {
	  String s = "";
	  for(int i=0; i < n; i++)
	  {
		  s += "*";
	  }
	  return s;
  }
  
  public static String makeStarsWithStringBuilder(int n)
  {
	  StringBuilder sb = new StringBuilder();
	  for(int i=0; i < n; i++)
	  {
		  sb.append("*");
	  }
	  return sb.toString();
  }

  
  public static void main(String[] args)
  {
	  int expCount = 100;
	  String result = "";
	  System.out.println("n \t\t Time");
	  for(int n = 0; n <= 2000000; n += 10000)
	  {
		  long start = System.currentTimeMillis();
		  for(int i=0; i < 1000; i++)
		  {
			  result = makeStarsWithStringBuilder(n);
		  }
		  long end = System.currentTimeMillis();
		  System.out.println(n + ","+ (end-start)/1000.0);
	  }
  }
}
