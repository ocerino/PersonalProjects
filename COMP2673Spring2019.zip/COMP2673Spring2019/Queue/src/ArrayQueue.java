public class ArrayQueue<T> implements Queue<T> 
{
	private int size;
	private int front;
	private T[] theQueue;
	
	public ArrayQueue(int capacity)
	{
		size = 0;
		front = 0;
		theQueue = (T[]) new Object[capacity];
	}
	
	public void enqueue(T v) 
	{
		if(size>=theQueue.length)
		{
			throw new IllegalStateException("Queue is full!");
		}
		
		theQueue[(front +size)%theQueue.length] = v;
		size++;
	}

	public T dequeue() 
	{
		if(size==0)
		{
			throw new IllegalStateException("Queue is empty!");
		}
		T returnValue = theQueue[front];
		theQueue[front] = null;
		front = (front + 1)%theQueue.length;
		size--;
		return returnValue;
	}

	public T front() {
		if(size==0)
		{
			throw new IllegalStateException("Queue is empty!");
		}
		return theQueue[front];
	}

	public boolean isEmpty() 
	{
		return size==0;
	}

	public int size() 
	{
		return size;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder("Queue: ");
		for(int i = 0; i< size; i++)
		{
			sb.append(theQueue[(front+i)%theQueue.length] + " ");
		}
		return sb.toString();
	}
	
}
