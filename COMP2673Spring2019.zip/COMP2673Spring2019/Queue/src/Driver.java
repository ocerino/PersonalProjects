
public class Driver {

	public static void main(String[] args) 
	{
		Queue<Integer> q = new ArrayQueue<>(10);
		
		for(int i = 0; i<10; i++)
		{
			q.enqueue((int) (Math.random()*100));
			System.out.println(q);
		}
		
		for(int i=0; i<5; i++)
		{
			System.out.println(q.dequeue()+" leaves the queue");
		}
		System.out.println(q);
		
		for(int i = 0; i<5; i++)
		{
			q.enqueue((int) (Math.random()*100));
			System.out.println(q);
		}
	}

}
