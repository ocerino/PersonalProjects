import java.util.Random;

public class RecursionTester {
	// suppose you are given the following two recursive
	//   methods for finding the minimum of an array:
	// version 1:
	public static int min1(int[] array) {
		return min1(array, array.length);
	}
	
	public static int min1(int[] array, int n) {
		if(n <= 0) {
			// no minimum exists
			throw new IllegalArgumentException("array is empty");
		} else if(n == 1) {
			// base case: if there's a single element, that's it!
			return array[0];
		} else {
			// recursive case: it's either the last element, or the
			//                 minimum of the first n-1 elements
			if(min1(array, n-1) < array[n-1]) {
				return min1(array, n-1);
			} else {
				return array[n-1];
			}
		}
	}
	
	// version 2:
	public static int min2(int[] array) {
		return min2(array, array.length);
	}
	
	public static int min2(int[] array, int n) {
		if(n <= 0) {
			// no minimum exists
			throw new IllegalArgumentException("array is empty");
		} else if(n == 1) {
			// base case: if there's a single element, that's it!
			return array[0];
		} else {
			// recursive case: it's either the last element, or the
			//                 minimum of the first n-1 elements
			int tmp = min2(array, n-1);
			if(tmp < array[n-1]) {
				return tmp;
			} else {
				return array[n-1];
			}
		}
	}
	
	// main method
	public static void main(String[] args) {
		// TODO: determine which of the previous two methods is faster!
		//min2 is the faster method based on the data gathered
		// TODO: (1) create some test arrays (of various sizes)
		
		
		System.out.println("n \t\tmin1 \t\tmin2");
		long start1 = 0;
		long start2 = 0;
		long end1 = 0;
		long end2 = 0;
		//data in ascending order
//		for(int i = 1; i <=33; i++)
//		{
//			int [] sample = new int [i];
//			int expCount = 100;
//			int temp = 0;
//			int runValue = 1000000000;
//			for(int n =0; n<i;n++)
//			{
//				sample[n] = n;
//				temp = sample[n];
//				start1 = System.currentTimeMillis();
//				
//				if(i>17)
//				{
//					runValue =1000000;
//				}
//				for(int j=0; j < runValue; j+=100000)
//				{
//					min1(sample);
//				}
//				end1 = System.currentTimeMillis();
//				
//				start2 = System.currentTimeMillis();
//				for(int j=0; j < 1000000000; j+=100000)
//				{
//					min2(sample);
//				}
//				end2 = System.currentTimeMillis();
//			}
//			System.out.println(temp + "\t\t"+ (end1-start1)/(double)runValue + "\t\t" + (end2-start2)/1000000000.0);
//		}
		//data in descending order
//		for(int i = 1; i <=33; i++)
//		{
//			int [] sample = new int [i];
//			int expCount = 100;
//			int temp = 0;
//			
//			for(int n =0; n<i;n++)
//			{
//				sample[n] = (i-1)- n;
//				temp = n;
//				start1 = System.currentTimeMillis();
//				for(int j=0; j < 1000000000; j+=100000)
//				{
//					min1(sample);
//				}
//				end1 = System.currentTimeMillis();
//				
//				start2 = System.currentTimeMillis();
//				for(int j=0; j < 1000000000; j+=100000)
//				{
//					min2(sample);
//				}
//				end2 = System.currentTimeMillis();
//			}
//			System.out.println(temp + "\t\t"+ (end1-start1)/1000000000.0 + "\t\t" + (end2-start2)/1000000000.0);
//		}
		//data in random order
		for(int i = 1; i <=33; i++)
		{
			int [] sample = new int [i];
			int expCount = 100;
			int temp = 0;
			int runValue = 1000000000;
			for(int n =0; n<i;n++)
			{
				sample[n] = (int)(Math.random()*i);
				temp = n;
				start1 = System.currentTimeMillis();
				
				if(i>17)
				{
					runValue =1000000;
				}
				for(int j=0; j < runValue; j+=100000)
				{
					min1(sample);
				}
				end1 = System.currentTimeMillis();
				
				start2 = System.currentTimeMillis();
				for(int j=0; j < 1000000000; j+=100000)
				{
					min2(sample);
				}
				end2 = System.currentTimeMillis();
			}
			System.out.println(temp + "\t\t"+ (end1-start1)/(double)runValue + "\t\t" + (end2-start2)/1000000000.0);
		}
		
		
		// TODO: (2) time how long it takes to find the minimum with each method

		// TODO: (3) display your results in a table, that can easily be graphed
	}
}
