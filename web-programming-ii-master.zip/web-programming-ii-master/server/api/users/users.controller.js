import { v4 as uuidv4 } from 'uuid';
import User from './users.model';

//let users = [];

export function  index(req, res){
    res.json({users: User.find()});

}

function findUser(id) {
    return User.findById(id);
}


export function show(req, res){
    console.log(req.params.id);
    /* Implementation here */
    let id = req.params.id;
    let currentUser = User.findById(id);
    if(currentUser != null){
        res.status(200);
        res.json(currentUser);
    }
    else {
        res.status(404);
        res.json({message: 'Not Found'});
    }
}

export function create(req, res)
{

        //let id = uuidv4();
        console.log(req.body.name);
        console.log(req.body.age);
        console.log(req.body.address);
        let name = req.body.name;
        // Validate parameter exists and is a string
        if (!name || typeof name !== 'string') {
            res.status(400);
            return res.json({
                error: 'name(String) is required'
            });
        }
        let address = req.body.address;
        // Validate parameter exists and is a string
        if (!address || typeof address !== 'string') {
            res.status(400);
            return res.json({
                error: 'address(String) is required'
            });
        }
        let age = req.body.age;
        // Validate parameter exists and is a number
        if (!age || typeof age !== 'number') {
            res.status(400);
            return res.json({
                error: 'age(Number) is required'
            });
        }
        // let user = {
        //     id,
        //     name,
        //     age,
        //     address
        // };
       let user = User.create({
            name,
            age,
            address
        });

        res.status(201);
        res.json(user);

}

export function upsert(req, res)
{

        //Get ID from URL request and set up user info
        let id = req.params.id;
        console.log(req.body.name);
        console.log(req.body.age);
        console.log(req.body.address)
        let name = req.body.name;
        // Validate parameter exists and is a string
        if (!name || typeof name !== 'string') {
            res.status(400);
            return res.json({
                error: 'name(String) is required'
            });
        }
        let address = req.body.address;
        // Validate parameter exists and is a string
        if (!address || typeof address !== 'string') {
            res.status(400);
            return res.json({
                error: 'address(String) is required'
            });
        }
        let age = req.body.age;
        // Validate parameter exists and is a number
        if (!age || typeof age !== 'number') {
            res.status(400);
            return res.json({
                error: 'age(Number) is required'
            });
        }
        let user = {
            id,
            name,
            age,
            address
        };
        //Search to see if ID matches an existing user

        let existingUser = User.findOneAndUpdate(user);
        //if user exists update with new info
        if (existingUser) {

            res.status(200);
            res.json(user);
        }
        //else create new user with id provided
        else{
            res.status(201);
            res.json(user);

        }



}

export function destroy(req, res)
{
    //Get ID from URL request
    let id = req.params.id;
    //Search to see if ID matches an existing user
    let existingUser = User.remove(id);
    //if user exists delete it
    if (existingUser) {
        res.status(204).send();
    }
    //else throw an error
    else{
        res.status(404);
        res.json({message: 'Not Found'});
    }
}
