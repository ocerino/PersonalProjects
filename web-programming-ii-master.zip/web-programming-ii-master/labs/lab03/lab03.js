import fs, {createWriteStream} from 'fs';
import zlib from 'zlib';

class lab03 {

    syncFileRead(filename) {
        var data = fs.readFileSync(filename);
        return data.toString();
    }

    asyncFileRead(filename, callback) {
        fs.readFile(filename, function (err, data) {
            if (err) return console.error(err);
            callback(data.toString());
        });
    }

    compressFileStream(filein, fileout) {
        /* Implement function here */
        return fs.createReadStream(filein).pipe(zlib.createGzip()).pipe(createWriteStream(fileout));
    }

    decompressFileStream(filein, fileout) {
        /* Implement function here */
        return fs.createReadStream(filein).pipe(zlib.createGunzip()).pipe(createWriteStream(fileout));
    }

    listDirectoryContents(directoryName, callback) {
        fs.readdir(directoryName, function(err, data){
            if(err) return console.error(err);
            data.forEach(function(data){
                console.log(data)
            });
        });
    }

}

export {lab03};
