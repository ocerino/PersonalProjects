db.towns.find({ name: /e/, famousFor : { $or : ['food', 'beer'] } }
