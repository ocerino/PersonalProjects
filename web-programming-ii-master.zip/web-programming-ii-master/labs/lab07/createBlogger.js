use blogger
db.articles.insert({Author:'J. R. R. Tolkien', Email:'tolkien54@gmail.com', CreationDate:'1954-07-29', Text:'The Fellowship of The Ring: A Review'})

