import {Component, Input, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';
import {UserService} from '../../services/user.service';
import {Review} from "../../interfaces/Review";
import {RecipeService} from "../../services/recipe.service";
import {Recipe} from "../../interfaces/Recipe";

@Component({
    selector: 'update-review',
    templateUrl: './updateReview.html',
    styleUrls: ['../modal.scss'],
})
export class UpdateReviewComponent {
    @Input() recipe: Recipe;
    @Input() review:Review;
    public formError: String;
    public formInfo: String;

    private modalRef?: BsModalRef;
    static parameters = [BsModalService, RecipeService];

    constructor(private modalService: BsModalService, private recipeService: RecipeService) {
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template);
    }

    updateReview() {
        this.recipeService.updateReview(this.review, this.recipe)
            .then(updatedReview => {
                this.formInfo = 'Review successfully updated!';
                this.formError = null;
            })
            .catch(error => {
                this.formInfo = null;
                this.formError = JSON.stringify(error);
            });
    }

}
