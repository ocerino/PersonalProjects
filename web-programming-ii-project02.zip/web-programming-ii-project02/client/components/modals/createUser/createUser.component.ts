import {Component, Input, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';
import {User} from '../../interfaces/User';
import {UserService} from '../../services/user.service';
@Component({
    selector: 'create-user',
    templateUrl: './createUser.html',
    styleUrls: ['../modal.scss'],
})

export class CreateUserComponent {

    @Input()  private user: User ={
        __v: undefined,
        _id: undefined,
        name: {
            firstName: undefined,
            lastName: undefined
        },
        email:undefined,
        username:undefined,
    };
    public formError: String;
    public formInfo: String;
    private modalRef?: BsModalRef;
    static parameters = [BsModalService, UserService];

    constructor(private modalService: BsModalService, private userService: UserService) {
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template);
    }

    createUser() {
        this.userService.createUser(this.user)
            .then(createdUser => {
                this.formInfo = 'User successfully created! Id:'+ createdUser._id;
                this.formError = null;
            })
            .catch(error => {
                this.formInfo = null;
                this.formError = JSON.stringify(error);
            });
    }
}
