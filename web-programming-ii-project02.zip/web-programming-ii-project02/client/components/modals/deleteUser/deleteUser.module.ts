import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { TooltipModule, TooltipConfig } from 'ngx-bootstrap/tooltip';

import { DeleteUserComponent } from './deleteUser.component';
import {ModalModule} from 'ngx-bootstrap/modal';

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        ModalModule.forRoot(),
        TooltipModule.forRoot(),
    ],
    declarations: [
        DeleteUserComponent
    ],

    exports: [
        DeleteUserComponent,
    ],

    providers: [
    ]
})
export class DeleteUserModule {}
