import {Component, Input, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';
import {User} from '../../interfaces/User';
import {UserService} from '../../services/user.service';

@Component({
    selector: 'delete-user',
    templateUrl: './deleteUser.html',
    styleUrls: ['../modal.scss'],
})
export class DeleteUserComponent {
    @Input() user: User;
    public formError: String;
    public formInfo: String;

    private modalRef?: BsModalRef;
    static parameters = [BsModalService, UserService];

    constructor(private modalService: BsModalService, private userService: UserService) {
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template);
    }

    deleteUser() {
        this.userService.deleteUser(this.user)
            .then(deletedUser => {
                this.formInfo = 'User successfully Deleted!';
                this.formError = null;
            })
            .catch(error => {
                this.formInfo = null;
                this.formError = JSON.stringify(error);
            });
    }
}
