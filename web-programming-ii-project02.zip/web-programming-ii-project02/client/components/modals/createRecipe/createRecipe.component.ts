import {Component, Input, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';
import {Recipe} from '../../interfaces/Recipe';
import {RecipeService} from '../../services/recipe.service';
// import {Reviews} from "../../interfaces/Reviews";
@Component({
    selector: 'create-recipe',
    templateUrl: './createRecipe.html',
    styleUrls: ['../modal.scss'],
})

export class CreateRecipeComponent {

    @Input()  private recipe: Recipe ={

        _id: undefined,
        name: undefined,
        description: undefined,
        image: undefined,
        prepTime: undefined,
        cookTime: undefined,
        directions: undefined,
        ingredients:undefined,
        reviews: undefined,
        __v: undefined
    };
    public formError: String;
    public formInfo: String;
    private modalRef?: BsModalRef;
    static parameters = [BsModalService, RecipeService];

    constructor(private modalService: BsModalService, private recipeService: RecipeService) {
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template);
    }

    createRecipe() {
        this.recipeService.createRecipe(this.recipe)
            .then(createdRecipe=> {
                this.formInfo = 'Recipe successfully created! Id:'+ createdRecipe._id;
                this.formError = null;
            })
            .catch(error => {
                this.formInfo = null;
                this.formError = JSON.stringify(error);
            });
    }
}
