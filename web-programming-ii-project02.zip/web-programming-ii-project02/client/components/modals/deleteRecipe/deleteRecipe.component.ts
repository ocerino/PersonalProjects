import {Component, Input, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';
import {Recipe} from '../../interfaces/Recipe';
import {RecipeService} from '../../services/recipe.service'


@Component({
    selector: 'delete-recipe',
    templateUrl: './deleteRecipe.html',
    styleUrls: ['../modal.scss'],
})
export class DeleteRecipeComponent{
    @Input() recipe: Recipe;
    public formError: String;
    public formInfo: String;
    static parameters = [BsModalService, RecipeService];

    private modalRef?: BsModalRef;
    constructor(private modalService:BsModalService, private recipeService: RecipeService) {
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template);
    }

    deleteRecipe() {
        this.recipeService.deleteRecipe(this.recipe)
            .then(deletedRecipe => {
                this.formInfo = 'Recipe successfully deleted!';
                this.formError = null;
            })
            .catch(error => {
                this.formInfo = null;
                this.formError = error.toString();
            });
    }
}
