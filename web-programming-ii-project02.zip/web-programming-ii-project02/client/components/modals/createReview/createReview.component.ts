import {Component, Input, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';
import {Review} from "../../interfaces/Review";
import {RecipeService} from "../../services/recipe.service";
import {Recipe} from "../../interfaces/Recipe";

@Component({
    selector: 'create-review',
    templateUrl: './createReview.html',
    styleUrls: ['../modal.scss'],
})

export class CreateReviewComponent {

    @Input()  private review: Review ={
        __v: undefined,
        _id:undefined,
        description: undefined,
        rating: undefined,
        createDate: Date.now(),
        user:undefined,
    };
    @Input() recipe:Recipe;
    public formError: String;
    public formInfo: String;
    private modalRef?: BsModalRef;
    static parameters = [BsModalService, RecipeService];

    constructor(private modalService: BsModalService, private recipeService: RecipeService) {
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template);
    }

    createReview() {
        this.recipeService.createReview(this.recipe, this.review)
            .then(createdReview => {
                this.formInfo = 'Review successfully created! Id:'+ createdReview._id;
                this.formError = null;
            })
            .catch(error => {
                this.formInfo = null;
                this.formError = JSON.stringify(error);
            });
    }
}
