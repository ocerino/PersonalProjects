import {Component, Input, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';
import {Review} from '../../interfaces/Review';
import {Recipe} from "../../interfaces/Recipe";
import {RecipeService} from '../../services/recipe.service'
import {UserService} from "../../services/user.service";


@Component({
    selector: 'delete-review',
    templateUrl: './deleteReview.html',
    styleUrls: ['../modal.scss'],
})
export class DeleteReviewComponent{
    @Input() review: Review;
    @Input() recipe: Recipe;
    public formError: String;
    public formInfo: String;
    static parameters = [BsModalService, RecipeService];

    private modalRef?: BsModalRef;
    constructor(private modalService:BsModalService, private recipeService: RecipeService) {
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template);
    }

    deleteReview() {
        this.recipeService.deleteReview(this.review,this.recipe)
            .then(deletedReview => {
                this.formInfo = 'Review successfully deleted!';
                this.formError = null;
            })
            .catch(error => {
                this.formInfo = null;
                this.formError = error.toString();
            });
    }
}
