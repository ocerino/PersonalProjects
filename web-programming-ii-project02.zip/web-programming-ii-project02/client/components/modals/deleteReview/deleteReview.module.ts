import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { TooltipModule, TooltipConfig } from 'ngx-bootstrap/tooltip';

import {DeleteReviewComponent} from './deleteReview.component';
import {ModalModule} from 'ngx-bootstrap/modal';

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        ModalModule.forRoot(),
        TooltipModule.forRoot(),
    ],
    declarations: [
        DeleteReviewComponent,
    ],

    exports: [
        DeleteReviewComponent,
    ],

    providers: [
    ]
})
export class DeleteReviewModule {}
