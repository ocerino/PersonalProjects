import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Recipe} from "../interfaces/Recipe";
import {Recipes} from "../interfaces/Recipes";
import {Review} from "../interfaces/Review";
import {Reviews} from "../interfaces/Reviews";

@Injectable()
export class RecipeService {
    static parameters = [HttpClient];

    constructor(private httpClient: HttpClient) {
        this.httpClient = httpClient;
    }

    getAllRecipes(): Promise<Recipe[]> {
        return this.httpClient
            .get<Recipe[]>('/api/recipes')
            .toPromise();
    }

    getRecipeById(recipeId): Promise<Recipe> {
        return this.httpClient
            .get<Recipe>(`/api/recipes/${recipeId}`)
            .toPromise();
    }

    getReview(reviewId:string,recipeId:string): Promise<Review>
    {
        let url = `/api/recipes/${recipeId}/reviews/${reviewId}`;
        return this.httpClient
            .get<Review>(url)
            .toPromise();
    }

    updateRecipe(recipe: Recipe): Promise<Recipe> {
        let url = `/api/recipes/${recipe._id}`;
        return this.httpClient
            .put<Recipe>(url, recipe)
            .toPromise();
    }

    updateReview(review:Review,recipe: Recipe): Promise<Review> {
        let url = `/api/recipes/${recipe._id}/reviews/${review._id}`;
        return this.httpClient
            .put<Review>(url, review)
            .toPromise();
    }


    createRecipe(recipe:Recipe): Promise<Recipe>{
        return this.httpClient
            .post<Recipe>('/api/recipes/',recipe)
            .toPromise();
    }

    createReview(recipe:Recipe, review:Review): Promise<Review>{
       // let url = `/api/${recipe._id}/reviews`;
        return this.httpClient
            .post<Review>(`/api/recipes/${recipe._id}/reviews`, review)
            .toPromise();
    }

    deleteRecipe(recipe:Recipe):Promise<Recipe>{
            let url = `/api/recipes/${recipe._id}`;
            return this.httpClient
                .delete<Recipe>(url)
                .toPromise();
        }

    deleteReview(review:Review,recipe:Recipe):Promise<Review>{
        let url = `/api/recipes/${recipe._id}/reviews/${review._id}`;
        return this.httpClient
            .delete<Review>(url)
            .toPromise();
    }
}
