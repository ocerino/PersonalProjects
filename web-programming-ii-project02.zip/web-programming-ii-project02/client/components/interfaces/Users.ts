import {User} from "./User";

export interface Users {
  users: User[];
}
