import {Reviews} from "./Reviews";

export interface Recipe {
    _id: string;
    name: string;
    description:string;
    image:string;
    prepTime:number;
    cookTime:number;
    directions:[string];
    ingredients:[{
        _id: string,
        name: string,
        amount: string
    }]
    reviews:Reviews;
    __v: number;
}
