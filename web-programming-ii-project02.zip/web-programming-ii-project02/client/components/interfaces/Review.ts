import {User} from "./User"

export interface Review {
    _id: string;
    description: string;
    rating: number;
    createDate: number;
    user: User;
    __v: number;
}
