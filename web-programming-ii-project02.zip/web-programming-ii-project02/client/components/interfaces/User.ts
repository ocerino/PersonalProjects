export interface User {
    _id: string;
    name: {
        firstName:string,
        lastName:string
    };
    email:string;
    username:string;
    __v: number;
}
