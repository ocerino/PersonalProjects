import {Component, OnInit} from '@angular/core';
import {Review} from '../../components/interfaces/Review';
import {RecipeService} from '../../components/services/recipe.service';
import {ActivatedRoute} from '@angular/router';
import {User} from "../../components/interfaces/User";
import {UserService} from "../../components/services/user.service";

@Component({
    selector: 'reviews',
    templateUrl: './reviews.html',
    styleUrls: ['./reviews.scss']
})
export class ReviewsComponent implements OnInit {

    public review: Review;
    public users:User[];
    public max = 5;
    public rate;
    public isReadonly = true;
    static parameters = [ActivatedRoute, RecipeService, UserService];

    constructor(private route: ActivatedRoute, private recipeService: RecipeService, private userService: UserService) {
        this.route = route;
        this.recipeService = recipeService;
        this.userService = userService;

    }

    private handleError(error: any): Promise<any> {
        console.error('Something has gone wrong', error);
        return Promise.reject(error.message || error);
    }

    public getUserData() {
        this.userService.getAllUsers()
            .then(response => {
                this.users = response as User[];
            })
            .catch(this.handleError);
    }

    ngOnInit() {
        this.route.params.subscribe(params => {
            this.recipeService.getReview(params.reviewId, params.recipeId)
                .then(review => {
                    this.review = review;
                    this.rate = this.review.rating;
                });
        });
    }
}
