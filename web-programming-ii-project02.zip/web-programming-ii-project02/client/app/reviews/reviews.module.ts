import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';


import {RouterModule, Routes} from '@angular/router';

import {TooltipModule} from 'ngx-bootstrap/tooltip';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {ReviewsComponent} from './reviews.component';

import { RatingModule } from 'ngx-bootstrap/rating';

export const ROUTES: Routes = [
    {path: 'recipes/:recipeId/reviews/:reviewId', component: ReviewsComponent},
];

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        BrowserAnimationsModule,
        RouterModule.forChild(ROUTES),
        RatingModule.forRoot(),

        TooltipModule.forRoot(),
    ],
    declarations: [
        ReviewsComponent
    ],

    exports: [
        ReviewsComponent
    ],

    providers: []
})
export class ReviewsModule {
}
