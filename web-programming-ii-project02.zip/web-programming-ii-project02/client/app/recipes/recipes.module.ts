import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';


import {RouterModule, Routes} from '@angular/router';

import {TooltipModule} from 'ngx-bootstrap/tooltip';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {RecipesComponent} from './recipes.component';
import {ReviewsComponent} from "../reviews/reviews.component";
import {ReviewsModule} from "../reviews/reviews.module";
import {UpdateReviewModule} from "../../components/modals/updateReview/updateReview.module";
import {DeleteReviewModule} from "../../components/modals/deleteReview/deleteReview.module";

export const ROUTES: Routes = [
    {path: 'recipes/:id', component: RecipesComponent},
    // {path: 'recipes/:recipeId/reviews/reviews', component: ReviewsComponent}
];

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        BrowserAnimationsModule,
        RouterModule.forChild(ROUTES),
        ReviewsModule,

        TooltipModule.forRoot(),
        UpdateReviewModule,
        DeleteReviewModule,
    ],
    declarations: [
        RecipesComponent
    ],

    exports: [
        RecipesComponent
    ],

    providers: []
})
export class RecipesModule {
}
