import {Component, OnInit} from '@angular/core';
import {Recipe} from '../../components/interfaces/Recipe';
import {Review} from "../../components/interfaces/Review";
import {Reviews} from "../../components/interfaces/Reviews";
import {RecipeService} from '../../components/services/recipe.service';
import {ActivatedRoute} from '@angular/router';

@Component({
    selector: 'recipes',
    templateUrl: './recipes.html',
    styleUrls: ['./recipes.scss']
})
export class RecipesComponent implements OnInit {

    public recipe: Recipe;
    public reviews:Reviews;
    public ingredients;
    static parameters = [ActivatedRoute, RecipeService];

    constructor(private route: ActivatedRoute, private recipeService: RecipeService) {
        this.route = route;
        this.recipeService = recipeService;
    }

    ngOnInit() {
        this.route.params.subscribe(params => {
            this.recipeService.getRecipeById(params.id)
                .then(recipe => {
                    this.recipe = recipe;
                    this.reviews = this.recipe.reviews;
                    this.ingredients=this.recipe.ingredients;
                });
        });
    }
}
