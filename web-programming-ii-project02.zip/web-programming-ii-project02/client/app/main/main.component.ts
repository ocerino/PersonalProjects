import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {UserService} from '../../components/services/user.service';
import {RecipeService} from "../../components/services/recipe.service";
import {User} from '../../components/interfaces/User';
import {Recipe} from '../../components/interfaces/Recipe';
import {Review} from "../../components/interfaces/Review";
import {Users} from '../../components/interfaces/Users'
import {Recipes} from "../../components/interfaces/Recipes";
import {Reviews} from "../../components/interfaces/Reviews";
@Component({
    selector: 'main',
    templateUrl: './main.html',
    styleUrls: ['./main.scss'],
})
export class MainComponent implements OnInit {
    public values: string[];
    public input: string;
    public users:User[];
    public recipes:Recipe[];
    // public reviews:Review[];
    static parameters = [HttpClient, UserService,RecipeService];

    constructor(private http: HttpClient, private userService: UserService, private recipeService: RecipeService) {
        this.http = http;
        this.userService=userService;
        this.recipeService=recipeService;
        this.getUserData();
        this.getRecipeData();
        //this.getReviewData();
    }
    private handleError(error: any): Promise<any> {
        console.error('Something has gone wrong', error);
        return Promise.reject(error.message || error);
    }

    public getUserData() {
        this.userService.getAllUsers()
            .then(response => {
                this.users = response as User[];
            })
            .catch(this.handleError);
    }

    public getRecipeData() {
        this.recipeService.getAllRecipes()
            .then(response => {
                this.recipes = response as Recipe[];
            })
            .catch(this.handleError);
    }

    // public getReviewData() {
    //     this.recipeService.getReview()
    //         .then(response => {
    //             this.reviews = response as Review;
    //         })
    //         .catch(this.handleError);
    // }

    ngOnInit() {

    }


}

