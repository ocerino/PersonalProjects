import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { RouterModule, Routes } from '@angular/router';

import { TooltipModule, TooltipConfig } from 'ngx-bootstrap/tooltip';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MainComponent } from './main.component';

//import {SquarePipe} from '../../components/pipes/square.pipe';
import {UserService} from '../../components/services/user.service';
import {RecipeService} from '../../components/services/recipe.service';

import {UsersModule} from "../users/users.module";
import {CreateUserModule} from "../../components/modals/createUser/createUser.module";
import {UpdateUserModule} from "../../components/modals/updateUser/updateUser.module";
import {DeleteUserModule} from "../../components/modals/deleteUser/deleteUser.module";

import {ReviewsModule} from "../reviews/reviews.module";
import {CreateReviewModule} from "../../components/modals/createReview/createReview.module";
import {UpdateReviewModule} from "../../components/modals/updateReview/updateReview.module";
import {DeleteReviewModule} from "../../components/modals/deleteReview/deleteReview.module";

import {RecipesModule} from "../recipes/recipes.module";
import {CreateRecipeModule} from "../../components/modals/createRecipe/createRecipe.module";
import {UpdateRecipeModule} from "../../components/modals/updateRecipe/updateRecipe.module";
import {DeleteRecipeModule} from "../../components/modals/deleteRecipe/deleteRecipe.module";

export const ROUTES: Routes = [
    { path: 'home', component: MainComponent },
];

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        BrowserAnimationsModule,
        RouterModule.forChild(ROUTES),
        UsersModule,
        CreateUserModule,
        UpdateUserModule,
        DeleteUserModule,
        RecipesModule,
        CreateRecipeModule,
        UpdateRecipeModule,
        DeleteRecipeModule,
        ReviewsModule,
        CreateReviewModule,
        UpdateReviewModule,
        DeleteReviewModule,
        TooltipModule.forRoot(),
],
declarations: [
    MainComponent,
    //  SquarePipe
],

    exports: [
        MainComponent,
    ],

    providers: [
        UserService,
        RecipeService,
    ]
})
export class MainModule {}
