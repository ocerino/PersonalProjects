import shared from "../../server/config/environment/shared";
export default shared;
