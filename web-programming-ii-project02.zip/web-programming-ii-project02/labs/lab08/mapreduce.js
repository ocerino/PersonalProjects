map = function() {

    emit({
        longitude: Math.floor(this.location.longitude)
    }, {
        count : 1
    });
}

reduce = function(key, values) {
    var total = 0;
    for (var i = 0; i < values.length; i++) {
        total += values[i].count;
    }
    return { count : total };
}



results = db.runCommand({
    mapReduce: 'cities',
    map: map,
    reduce: reduce,

    out: 'cities.report'
})

db.cities.report.find({"_id.longitude" : 42})



// finalize: function(key, reducedValue) {
//     return {total: reducedValue.count};
// },
//
// reduce = function(key, values) {
//     var total = 0;
//     for(var i = 0; i < values.length; i++) {
//         var data = values[i];
//         if('total' in data) {
//             total += data.total;
//         } else {
//             total += data.count;
//         }
//     }
//     return { total : total };
// }
