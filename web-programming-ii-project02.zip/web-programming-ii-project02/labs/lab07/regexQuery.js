db.towns.find( { name: { $regex: /new/'i'} }
