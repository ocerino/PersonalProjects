#include <stdio.h>
#include <stdlib.h> //malloc
#include <string.h>


typedef struct tnode {
  int weight;
  int c;
  struct tnode* left;
  struct tnode* right;
  struct tnode* parent;
} HuffmanNode;

typedef struct node{
  HuffmanNode node;
  struct node* next;
} LinkedList;

LinkedList* llCreate();
int llIsEmpty(LinkedList* ll);
void llDisplay(LinkedList* ll);
void llAdd(LinkedList** ll, HuffmanNode newNode);
void llFree(LinkedList* ll);
void list_add_in_order(LinkedList** ll, HuffmanNode newNode);
