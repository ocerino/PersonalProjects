#include "linkedList.h"

void llDisplay(LinkedList* ll) {
  LinkedList* p = ll;
  printf("[");
  while (p != NULL) {
    printf("(%d, %d), ", (*p).node.c, (*p).node.weight);
    p = p->next;
  }
  printf("]\n");
} 

void list_add_in_order(LinkedList** ll, HuffmanNode node){
  LinkedList* newNode = (LinkedList*) malloc(1*sizeof(LinkedList));
  newNode->node = node;
  newNode->next = NULL;
  LinkedList* p = *ll;
  if(p == NULL){
   *ll = newNode;
  }
  else{
    while(p->next!=NULL && p->node.weight< node.weight && node.weight>p->next->node.weight){
      p = p->next;
    }
    newNode->next = p->next;
    p->next = newNode;
  }
}

void removeNode(LinkedList* ll, int index){
  int size =128;
  if(ll != NULL && index<size){
    LinkedList* p = ll;
    if(index == 0){
      ll = p->next;
     
    }
    else{
      int i =0;
      while(p!=NULL && i<index-1){
	p = p->next;
	i++;
      }
      LinkedList* temp = p->next;
      LinkedList* temp2 = temp->next;
      p->next = temp2;
     
    }
  }
}

HuffmanNode* createFreqTable(char* file){
  FILE *filePointer;
  filePointer=fopen(file,"r");


  int size=128;
  char letter;
  struct tnode* table= ((HuffmanNode*)malloc(size*sizeof(HuffmanNode)));
  

  for(int i=0; i<size; i++){
    table[i].weight=0;
    table[i].left=NULL;
    table[i].right=NULL;
    table[i].parent=NULL;
    table[i].c=i;   
  }

  while(fscanf(filePointer,"%c", &letter)&&!feof(filePointer)){
    table[(int)letter].weight+=1;
  }

  fclose(filePointer);
 
  return table;
}

HuffmanNode* createHuffmanTree(HuffmanNode* leafNodes){
  //should take in this array of leaf nodes and form the Huffman Tree.  To do so, you will need to use your LinkedList.  You should place all your nodes in the list in order.  Then simply repeatedly combine the lowest two nodes, forming a new node, and add that new node back into the list.  When you are done, you should have the root node that you need to return.
  int size = 128;
  HuffmanNode* result = (HuffmanNode*)malloc(size*sizeof(HuffmanNode));
  LinkedList* temp;

  for(int i=0; i<size;i++){
    list_add_in_order(&temp, leafNodes[i]);
  }
  for(int i=0; i<size; i++){
    result [i] = temp[i].node;
  }
  llDisplay(temp);
  
  while(size>1){
    HuffmanNode first = result[0];
    HuffmanNode second = result[1];
    HuffmanNode combo;
    combo.weight = first.weight + second.weight;
    combo.left = &first;
    combo.right = &second;
    first.parent = &combo;
    second.parent = &combo;
    removeNode(temp, 0);
    removeNode(temp, 1);
    list_add_in_order(&temp, combo);
    size--;
  }
  llDisplay(temp);
  
  return result;
  
}

void encodeFile(char* argv , HuffmanNode* nodeArr){
  // takes in the name of the file you would like to encode.  This could be decind.txt or it could be some other file that has a similar letter distribution as decind.txt.  As you read in each character from the file you should find that character in the leafNodes array.  Then you should use the tree that is attached to that leaf node to walk up to the root node and discover the Huffman code that should be used to encode that character.  Once the number of bits you need to write out goes over 8, you should write out that byte to the .huf file.  That is, you should not read in the entire file and turn it into a large string of 0s and 1s in memory before writing out.  You should write it out as you have enough to write out.
  FILE* stream;
  if((stream = fopen(argv,"r")) ==NULL){
    printf("That file doesn't exist. Please enter a valid file name\n");
  }
  else{
    strcat(argv, ".huf");

    //encode file

  }
    
}

void decodeFile(char* argv , HuffmanNode* root){
  //similar to encode except that it will work top-down from the root of the Huffman tree to the leaf nodes.
  FILE* stream;
  if((stream = fopen(argv,"r")) ==NULL){
    printf("That file doesn't exist. Please enter a valid file name\n");
  }
  else{
    //Decode file
    
  }
}

int main(int argc, char *argv[]) {
  
  
  // Check the make sure the input parameters are correct

  if (argc != 3) {
    printf("Error: The correct format is \"hcompress -e filename\" or \"hcompress -d filename.huf\"\n"); fflush(stdout);

    exit(1);

  }

  // Create the frequency table by reading the generic file
  HuffmanNode* leafNodes = createFreqTable("decind.txt");
  
  // Create the huffman tree from the frequency table
  HuffmanNode* treeRoot = createHuffmanTree(leafNodes);
  
  // encode
  if (strcmp(argv[1], "-e") == 0) {
    // Pass the leafNodes since it will process bottom up
    encodeFile(argv[2], leafNodes);
  }
  else { // decode
    // Pass the tree root since it will process top down
    decodeFile(argv[2], treeRoot);
  }
  return 0;
}
