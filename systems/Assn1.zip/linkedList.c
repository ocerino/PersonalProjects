#include "linkedList.h"

LinkedList* llCreate() {
  return NULL;
}

int llIsEmpty(LinkedList* ll) {
  return (ll == NULL);
}

void llDisplay(LinkedList* ll) {
  LinkedList* p = ll;
  printf("[");
  while (p != NULL) {
    printf("(%c, %d), ", (*p).node.c, (*p).node.weight);
    p = p->next;
  }
  printf("]\n");
}

void llAdd(LinkedList** ll, HuffmanNode node) {
  // Create the new node
  LinkedList* newNode = (LinkedList*)malloc(1 * sizeof(LinkedList));
  newNode->node = node;
  newNode->next = NULL;
  // Find the end of the list
  LinkedList* p = *ll;
  if (p == NULL) {
    // Add first element
    *ll = newNode;
    // This is why we need ll to be a **
  } else {
    while (p->next != NULL) {
      p = p->next;
    }
    // Attach it to the end
    p->next = newNode;
  }
}

void list_add_in_order(LinkedList** ll, HuffmanNode node){
  LinkedList* newNode = (LinkedList*) malloc(1*sizeof(LinkedList));
  newNode->node = node;
  newNode->next = NULL;
  LinkedList* p = *ll;
  if(p == NULL){
    *ll = newNode;
  }
  else{
    while(p->next!=NULL && node.weight > p->node.weight){
      p = p->next;
    }
    newNode->next = p->next;
     p->next = newNode;
  }
}


void llFree(LinkedList* ll) {
  LinkedList* p = ll;
  while (p != NULL) {
    LinkedList* oldP = p;
    p = p->next;
    free(oldP);
  }
}

 int main() {
  LinkedList* l = llCreate();

  HuffmanNode test1;
  test1.c = 'a';
  test1.weight = 1;

  HuffmanNode test2;
  test2.c = 'b';
  test2.weight = 2;

  HuffmanNode test3;
  test3.c = 'c';
  test3.weight = 3;

  HuffmanNode test4;
  test4.c = 'd';
  test4.weight =1;

  llDisplay(l);
  list_add_in_order(&l, test1);
  llDisplay(l);
  list_add_in_order(&l, test2);
  llDisplay(l);
  list_add_in_order(&l, test3);
  llDisplay(l);
  list_add_in_order(&l, test4);
  llDisplay(l);
  llFree(l);
}
