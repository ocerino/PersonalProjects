
public class Question4 {

	public static void main(String[] args) 
	{
		int[] randomArray;
		int[] sortedArray;
		long start1 = 0;
		long start2 = 0;
		long end1 = 0;
		long end2 = 0;
		int runValue = 1000000000;
		System.out.println("insertion\tmerge");
		for (int i = 1; i < 50; i++) 
		{
			start1 = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 250000) 
			{
				randomArray = new int[i*200];
				for(int k =0; k<randomArray.length;k++)
				{
				randomArray[k] = (int) Math.random() * k;
				}
				insertionSort(randomArray);
			}
			end1 = System.currentTimeMillis();
			start2 = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 2500000) 
			{
				randomArray = new int[i*200];
				for(int k =0; k<randomArray.length;k++)
				{
				randomArray[k] = (int) Math.random() * k;
				}
				iterativeMergeSort(randomArray);
			}
			end2 = System.currentTimeMillis();
			System.out.println((end1 - start1) / (double) runValue + "\t" + (end2 - start2) / (double) runValue);
			}
	}
	
	public static void insertionSort(int[] a) 
	{
		for (int j = 1; j < a.length; j++) 
		{
			int key = a[j];
			int i = j - 1;
			while (i > 0 && a[i] > key) 
			{
				a[i + 1] = a[i];
				i = i--;
			}
			a[i + 1] = key;
		}
	}
	
	public static void iterativeMergeSort(int a[]) 
	{ 
	   int size;  //current size of subarrays to be merged; size varies from 1 to n/2 
	   int p; //starting index of left subarray to be merged 
	  
	   for (size=1; size<a.length; size = 2*size) 
	   { 
	       // Pick starting point of different subarrays of size 
	       for (p=0; p<a.length-1; p += 2*size) 
	       { 
	           // Find ending point of left subarray. q+1 is starting point of right 
	           int q = Math.min(p + size - 1, a.length-1); 
	  
	           int r = Math.min(p+ 2*size - 1, a.length-1); 
	  
	           // Merge Subarrays a[leftStart...q] & a[q+1...r] 
	           merge(a, p,q, r); 
	       } 
	   } 
	} 
	
	public static void merge(int a[], int p, int q, int r) 
	{ 
	    int i, j, k; 
	    int n1 = q - p + 1; 
	    int n2 =  r - q; 
	  
	    // create temp arrays 
	    int[] L=new int[n1];
		int[] R= new int [n2]; 
	  
	    //Copy data to temp arrays L[] and R[]
	    for (i = 0; i < n1; i++) 
	    {
	        L[i] = a[p + i]; 
	    }
	    for (j = 0; j < n2; j++) 
	    {
	        R[j] = a[q + 1+ j]; 
	    }	  
	    //Merge the temp arrays back into a[p..r]
	    i = 0; 
	    j = 0; 
	    k = p; 
	    while (i < n1 && j < n2) 
	    { 
	        if (L[i] <= R[j]) 
	        { 
	            a[k] = L[i]; 
	            i++; 
	        } 
	        else
	        { 
	            a[k] = R[j]; 
	            j++; 
	        } 
	        k++; 
	    } 
	    //Copy the remaining elements of L[], if there are any
	    while (i < n1) 
	    { 
	        a[k] = L[i]; 
	        i++; 
	        k++; 
	    } 
	  
	    //Copy the remaining elements of R[], if there are any
	    while (j < n2) 
	    { 
	        a[k] = R[j]; 
	        j++; 
	        k++; 
	    } 
	} 
	
	public static void printArray(int a[]) 
	{ 
	    int i; 
	    System.out.print("( ");
	    for (i=0; i < a.length; i++) 
	    {
	        System.out.print(a[i] + " "); 
	    }
	    System.out.print(")\n"); 
	} 

}
