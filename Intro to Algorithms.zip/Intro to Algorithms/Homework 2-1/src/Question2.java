
public class Question2 
{

	public static void main(String[] args) 
	{
		int[] randomArray;
		int[] sortedArray;
		long start1 = 0;
		long start2 = 0;
		long end1 = 0;
		long end2 = 0;
		int runValue = 1000000000;
		System.out.println("random\t\tsorted");
		for (int i = 1; i < 45; i++) 
		{
			start1 = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 10) 
			{
				randomArray = new int[i];
				for(int k =0; k<randomArray.length;k++)
				{
				randomArray[k] = (int) Math.random() * k;
				}
				insertionSort(randomArray);
			}
			end1 = System.currentTimeMillis();
			start2 = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 50) 
			{
				sortedArray = new int[i];
				for(int k =0; k<sortedArray.length;k++)
				{
				sortedArray[k] = k;
				}
				insertionSort(sortedArray);
			}
			end2 = System.currentTimeMillis();
			System.out.println((end1 - start1) / (double) runValue + "\t" + (end2 - start2) / (double) runValue);
		}

	}

	public static void insertionSort(int[] a) 
	{
		for (int j = 1; j < a.length; j++) 
		{
			int key = a[j];
			int i = j - 1;
			while (i > 0 && a[i] > key) 
			{
				a[i + 1] = a[i];
				i = i--;
			}
			a[i + 1] = key;
		}
	}
}
