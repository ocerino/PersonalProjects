
public class DivideAndConquerMaxSubarraySum {

	public static void main(String[] args) 
	{
//		int [] a = {13,-3,-25,20,-3,-16,-23,18,20,-7,12,-5,-22,15,-4,7};
//		int[] result =divideAndConquerMaxSubarraySum(a,0,a.length-1);
//		System.out.println("start index:" +result[0] +"\tend index:"+ result[1]+"\tsum:"+result[2]);
		int[] randomArray;
		long start = 0;
		long end = 0;
		int runValue = 1000000;
		int factor = 100000;
		System.out.println("Divide & Conquer\t\tsize");
		for (int i = 1; i <= 50; i++) 
		{
			start = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 1000) 
			{
				randomArray = new int[i*factor];
				for(int k =0; k<randomArray.length;k++)
				{
				randomArray[k] = (int) (Math.random() * k-k/2);
				}
				divideAndConquerMaxSubarraySum(randomArray,0,randomArray.length-1);
			}
			end = System.currentTimeMillis();
			System.out.println((end - start) / (double) runValue+"\t\t"+i*factor);
		}
	}

	public static int[] divideAndConquerMaxSubarraySum(int[] a,int low,int high)
	{
		int leftLow,leftHigh,leftSum,rightLow,rightHigh,rightSum,crossLow,crossHigh,crossSum;
		if(high==low)//base case: 1 element
		{
			int [] result = {low,high,a[low]};
			return result;
		}
		else
		{
			int mid = (low+high)/2;
			//recursively do left side
			int [] temp = divideAndConquerMaxSubarraySum(a,low, mid);
			leftLow = temp[0];
			leftHigh = temp[1];
			leftSum = temp[2];
			//recursively do right side
			temp = divideAndConquerMaxSubarraySum(a,mid+1,high);
			rightLow = temp[0];
			rightHigh = temp[1];
			rightSum = temp[2];
			//finds crossing sum
			temp = findMaxCrossingSubarray(a,low,mid,high);
			crossLow = temp[0];
			crossHigh = temp[1];
			crossSum = temp[2];
			
			if(leftSum>=rightSum && leftSum>=crossSum)
			{
				int [] result = {leftLow,leftHigh,leftSum};
				return result;
			}
			else if(rightSum>=leftSum && rightSum>=crossSum)
			{
				int [] result = {rightLow,rightHigh,rightSum};
				return result;
			}
			else
			{
				int [] result = {crossLow,crossHigh,crossSum};
				return result;
			}
		}
	}
	
	private static int[] findMaxCrossingSubarray(int[] a, int low, int mid, int high)
	{
		int maxLeft=0;
		int leftSum=0;
		int sum=0;
		for(int i = mid; i>=low;i--)
		{
			sum += a[i];
			if(sum> leftSum)
			{
				leftSum=sum;
				maxLeft =i;
			}
		}
		int maxRight=0;
		int rightSum=0;
		sum=0;
		for(int j=mid+1;j<=high;j++)
		{
			sum+=a[j];
			if(sum>rightSum)
			{
				rightSum=sum;
				maxRight=j;
			}
		}
		int [] result = {maxLeft, maxRight, leftSum+rightSum};
		return result;
	}
}
