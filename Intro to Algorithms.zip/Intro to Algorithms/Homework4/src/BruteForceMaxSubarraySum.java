
public class BruteForceMaxSubarraySum {

	public static void main(String[] args) 
	{
//		int [] a = {13,-3,-25,20,-3,-16,-23,18,20,-7,12,-5,-22,15,-4,7};
//		int[] result =bruteForceMaxSubarraySum(a);
//		System.out.println("start index:" +result[0] +"\tend index:"+ result[1]+"\tsum:"+result[2]);
		int[] randomArray;
		long start = 0;
		long end = 0;
		int runValue = 100000;
		int factor = 100000;
		System.out.println("Brute Force\t\tsize");
		for (int i = 1; i <= 50; i++) 
		{
			start = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 100000) 
			{
				randomArray = new int[i*factor];
				for(int k =0; k<randomArray.length;k++)
				{
				randomArray[k] = (int) (Math.random() * k-k/2);
				}
				bruteForceMaxSubarraySum(randomArray);
			}
			end = System.currentTimeMillis();
			System.out.println((end - start) / (double) runValue+"\t\t"+i*factor);
		}
		
	}
	
	public static int[] bruteForceMaxSubarraySum(int[] a)
	{
		int currSum=0;
		int maxSum=0;
		int start=0;
		int end=0;
		for(int i =0;i<a.length;i++)
		{
			for(int j =i;j<a.length;j++)
			{
				currSum+=a[j];
				if(currSum<1)
				{
					start=i+1;
					currSum=0;
				}
				
				if(currSum>maxSum)
				{
					maxSum=currSum;
					end=j;
				}
			}
		}
		int[] result ={start,end,maxSum};
		
		return result;
	}

}
