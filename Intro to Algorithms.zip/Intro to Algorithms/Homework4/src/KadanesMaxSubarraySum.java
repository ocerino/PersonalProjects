
public class KadanesMaxSubarraySum {

	public static void main(String[] args) 
	{
//		int [] a = {13,-3,-25,20,-3,-16,-23,18,20,-7,12,-5,-22,15,-4,7};
//		int[] result =kadaneMaxSubarraySum(a);
//		System.out.println("start index:" +result[0] +"\tend index:"+ result[1]+"\tsum:"+result[2]);
		int[] randomArray;
		long start = 0;
		long end = 0;
		int runValue = 1000000;
		int factor = 100000;
		System.out.println("Kadane's\t\tsize");
		for (int i = 1; i <= 50; i++) 
		{
			start = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 1000) 
			{
				randomArray = new int[i*factor];
				for(int k =0; k<randomArray.length;k++)
				{
				randomArray[k] = (int) (Math.random() * k-k/2);
				}
				kadaneMaxSubarraySum(randomArray);
			}
			end = System.currentTimeMillis();
			System.out.println((end - start) / (double) runValue+"\t\t"+i*factor);
		}
	}

	public static int [] kadaneMaxSubarraySum(int [] a)
	{
		int maxSumSoFar = 0;
		int maxSumToK = 0;
		int start = 0;
		int end = 0;
		int count = 0;
		for(int k =0; k<a.length;k++)
		{
			maxSumToK = maxSumToK +a[k];
			if(maxSumToK<0)
			{
				maxSumToK=0;
				start=k+1;
			}
			if(maxSumSoFar< maxSumToK)
			{
				maxSumSoFar = maxSumToK;
				end=count;
			}
			count++;
		}
		int [] result = {start,end,maxSumSoFar};
		return result;
	}
}
