import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.*;

public class QuickHull {

	public static void main(String[] args) 
	{
		

		//System.out.println(test);
		//System.out.println(QuickHull(test));
		
		long start1 = 0;
		long start2 = 0;
		long end1 = 0;
		long end2 = 0;
		int runValue = 1000000000;
		System.out.println("quick hull");
		for (int i = 1; i < 45; i++) 
		{
			start1 = System.currentTimeMillis();
			for (int j = 0; j < runValue; j += 10) 
			{
				ArrayList<Point> test = new ArrayList<Point>();
				Point p = new Point((int)(Math.random()*500), (int)(Math.random()*500));
				test.add(p);
			}
			end1 = System.currentTimeMillis();
			System.out.println((end1 - start1) / (double) runValue);
		}
	}
	
	public static ArrayList<Point> QuickHull(ArrayList<Point> s)
	{
		Point minX = new Point();
		Point maxX = new Point();
		ArrayList<Point> upper = new ArrayList<Point>();
		ArrayList<Point> lower = new ArrayList<Point>();
		for(Point p : s)
		{
			if(minX.getX()==0 && minX.getY()==0)
			{
				minX = p;
			}
			else if(minX.getX()>p.getX())
			{
				minX = p;
			}
			if(maxX.getX()==0 && maxX.getY()==0)
			{
				maxX = p;
			}
			else if(maxX.getX()<p.getX())
			{
				maxX = p;
			}
		}
		
		for(Point p: s)
		{
			if(isLeftTurn(minX,maxX,p))
			{
				upper.add(p);
			}
			else if(isRightTurn(minX,maxX,p))
			{
				lower.add(p);
			}
		}
		
		ArrayList <Point> convexHull = new ArrayList<Point>();
		QuickHullRecursive(upper, minX, maxX, convexHull);
		QuickHullRecursive(lower, minX, maxX, convexHull);			
			
		return convexHull;
		
	}
	
	public static void QuickHullRecursive(ArrayList<Point> s, Point a, Point b, ArrayList<Point> r)
	{
		Point furthest=s.get(0);
		double c = 0;
		for(Point p: s)
		{
			if(ValueBasedOnDistance(a,b, p) > c)
			{
				c = ValueBasedOnDistance(a,b, p);
				furthest = p;
			}
		}
		r.add(furthest);
		ArrayList<Point> left = new ArrayList<Point>();
		ArrayList<Point> right = new ArrayList<Point>();
		for(Point p:s)
		{
			if(p.getX() < furthest.getX())
			{
				left.add(p);
			}
			else if (p.getX()> furthest.getX())
			{
				right.add(p);
			}
		}
		if(left.size()!=0)
		{
		QuickHullRecursive(left, a, furthest, r);
		}
		if(right.size()!=0)
		{
		QuickHullRecursive(right, furthest, b, r);
		}
		
		
	}

	public static double ValueBasedOnDistance(Point a, Point b, Point p)
	{
		double v1x = b.getX() - a.getX();
		double v1y = b.getY() - a.getY();
		
		double v2x = p.getX() - a.getX();
		double v2y = p.getY() - a.getY();
		
		return Math.abs(v1x*v2y - v1y*v2x);
		
	}
	
	public static boolean isLeftTurn(Point2D p1, Point2D p2, Point2D p3)
	{
		double v1x = p2.getX() - p1.getX();
		double v1y = p2.getY() - p1.getY();
		
		double v2x = p3.getX() - p2.getX();
		double v2y = p3.getY() - p2.getY();
		return v1x*v2y - v1y*v2x > 0;
	}

	public static boolean isRightTurn(Point2D p1, Point2D p2, Point2D p3)
	{
		double v1x = p2.getX() - p1.getX();
		double v1y = p2.getY() - p1.getY();
		
		double v2x = p3.getX() - p2.getX();
		double v2y = p3.getY() - p2.getY();
		return v1x*v2y - v1y*v2x < 0;
	}
}
