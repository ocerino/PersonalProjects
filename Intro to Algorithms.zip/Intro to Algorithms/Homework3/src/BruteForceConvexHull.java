import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.*;

public class BruteForceConvexHull 
{

	public static void main(String[] args) 
	{
		ArrayList<Point> test = new ArrayList<Point>();
		for(int i = 0; i<100;i++)
		{
			Point p = new Point((int)(Math.random()*500), (int)(Math.random()*500));
			test.add(p);
		}

		System.out.println(test);
		System.out.println(BruteForceConvexHull(test));

	}
	
	public static ArrayList<Point> BruteForceConvexHull(ArrayList<Point> s)
	{
		ArrayList <Point> convexHull = new ArrayList<Point>();
		for(Point i : s)
		{
			for(Point j: s)
			{
				while(j != i)
				{
					int leftTurnCount = 0;
					for(Point k: s)
					{
						while(k != i && k != j)
						{
							if(isLeftTurn(i,j,k))
							{
								leftTurnCount = leftTurnCount + 1;
							}
						}
						if(leftTurnCount == 0 || leftTurnCount == s.size()-2)
						{
							convexHull.add(i);
							convexHull.add(j);
						}
					}
				}
				
			}
		}
		return convexHull;
		
	}
	
	public static boolean isLeftTurn(Point2D p1, Point2D p2, Point2D p3)
	{
		double v1x = p2.getX() - p1.getX();
		double v1y = p2.getY() - p1.getY();
		
		double v2x = p3.getX() - p2.getX();
		double v2y = p3.getY() - p2.getY();
		return v1x*v2y - v1y*v2x > 0;
	}

	public static boolean isRightTurn(Point2D p1, Point2D p2, Point2D p3)
	{
		double v1x = p2.getX() - p1.getX();
		double v1y = p2.getY() - p1.getY();
		
		double v2x = p3.getX() - p2.getX();
		double v2y = p3.getY() - p2.getY();
		return v1x*v2y - v1y*v2x < 0;
	}
}
