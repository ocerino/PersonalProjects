import java.io.*;
import java.util.*;

public class Question5 {

	public static void main(String[] args) 
	{
//		System.out.println("G.C.D of 81 and 153 is: " + consecIntCheck(153,81));
//		System.out.println("G.C.D of 81 and 153 is: " + euclids(153,81));
		System.out.println("Consec Int \t\tEuclid's");
		long[] a = new long[30],b= new long[30];
		FileInputStream fileInput = null;
		Scanner inputStream = null;
		try {
			fileInput = new FileInputStream("fib.txt");	
			inputStream = new Scanner(fileInput);

			a[0] = inputStream.nextInt();
			b[0] = inputStream.nextInt();;
			for(int i=0;i<a.length;i++)
			{
					a[i] = b[i];
					b[i] = inputStream.nextInt();
			}
		}
		catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			System.exit(0);			
		}
		
		long start1 = 0;
		long start2 = 0;
		long end1 = 0;
		long end2 = 0;
		for(int i = 1; i <=33; i++)
		{
			int runValue = 1000000000;
			for(int n1 =0; n1<i;n1++)
			{
				
				start1 = System.currentTimeMillis();
				for(int j=0; j < runValue; j+=250)
				{
					for(int k =0; k<a.length;k++)
					consecIntCheck(a[k],b[k]);
				}
				end1 = System.currentTimeMillis();
				
				start2 = System.currentTimeMillis();
				for(int j=0; j < runValue; j+=250)
				{
					for(int k =0; k<a.length;k++)
					euclids(a[k],b[k]);
				}
				end2 = System.currentTimeMillis();
			}
			System.out.println((end1-start1)/(double)runValue + "\t\t" + (end2-start2)/1000000000.0);
		}
	}

	public static long consecIntCheck(long a, long b) {
		long gcd = 1;
		for (int i = 1; i <= a && i <= b; i++) 
		{
			if (a % i == 0 && b % i == 0)
				gcd = i;
		}
		return gcd;
	}

	public static long euclids(long a, long b) 
	{
		if (b == 0) 
		{
			return a;
		}
		return euclids(b, a % b);
	}
}
