
public class Question4 {

	public static void main(String[] args) {
		int n = 10;
		long x = (long) ((Math.random()*48)+2);
		int[] a = new int [n];
		for(int i=0;i<a.length;i++) 
		{
			a[i] = (int) (Math.random()*99+1);
		}
		
//		System.out.println(naive(a,x));
//		System.out.println(horner(a,x));
		System.out.println("naive \t\thorner");
		long start1 = 0;
		long start2 = 0;
		long end1 = 0;
		long end2 = 0;
		for(int i = 1; i <=33; i++)
		{
			int runValue = 1000000000;
			for(int n1 =0; n1<i;n1++)
			{
				
				start1 = System.currentTimeMillis();
				for(int j=0; j < runValue; j+=250)
				{
					naive(a,x);
				}
				end1 = System.currentTimeMillis();
				
				start2 = System.currentTimeMillis();
				for(int j=0; j < runValue; j+=250)
				{
					horner(a,x);
				}
				end2 = System.currentTimeMillis();
			}
			System.out.println((end1-start1)/(double)runValue + "\t\t" + (end2-start2)/1000000000.0);
		}
		
	}
	
	
	public static long naive(int[] a,long x)
	{
		long p = 0;
		for (int i =a.length - 1; i >= 0; i--)
		{
			p += a[i]*(Math.pow(x, i));
		}
		return p;
	}

	public static long horner(int[] a,long x)
	{
		long  p = 0;
		for (int i =a.length - 1; i >= 0; i--)
		{
			p = a[i] + (x * p);
		}
		return p;
	}
}


